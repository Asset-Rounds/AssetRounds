# AssetRounds — Field Inspections brand system (Brand Handoff V4.1)

## Identity architecture

The permanent master brand is **AssetRounds**. The broad descriptor is **Field Inspections**.

The initial App Store title remains **AssetRounds: Sign Inspection** because the first product is intentionally specific. Expansion names describe a module or customer-facing product page; they do not replace the master identity.

Examples:

- AssetRounds: Sign Inspection
- AssetRounds: Exterior Lighting
- AssetRounds: Playground & Park Safety

Do not rename the master product to `Site Inspections` merely because additional verticals are added. AssetRounds is the expandable identity.

## Mark meaning

- Center: the physical asset being documented.
- Open orbit: a recurring inspection round and continuing history.
- Waypoint: an observed checkpoint, evidence event, or completed step.

The mark is deliberately industry-neutral. It is not a sign, lamp, playground component, shield, checkmark, or compliance seal.

## Product character

The visual priority order is:

1. **Dependable** — work and evidence feel safely recorded.
2. **Clear** — the next action and current state are obvious outdoors and at night.
3. **Evidence-led** — photos, findings, work, rechecks, and reports stay connected.
4. **Premium** — polish comes from restraint, typography, spacing, speed, and report quality.

Current inspection-app reviews repeatedly reward fast learning, professional reports, photo evidence, and less paperwork. They criticize slow starts, lost drafts, weak camera behavior, and reports that separate photos from their explanations. The brand must therefore communicate practical trust, not decorative luxury. See `Research/COMPETITOR_REVIEW_EVIDENCE.md`.

## Color system

| Token | Light | Dark | Primary use |
| --- | --- | --- | --- |
| Accent teal | `#006D75` | `#2BB8C2` | Branded interaction and selected state |
| Deep teal | `#0B4E53` | `#8ADDE3` | Brand headings and one-color mark |
| Checkpoint green | `#147D47` | `#53D78B` | Completed/positive state with a separate label/icon |
| Brand canvas | `#F3F9F9` | `#061E26` | App icon and limited brand moments |
| Ink | `#11181C` | `#F7FAFA` | High-priority text |
| Slate | `#47565D` | `#B8C5C8` | Secondary text |

Measured WCAG relative-luminance ratios on the paired brand canvas:

| Foreground | Light ratio | Dark ratio |
| --- | ---: | ---: |
| Accent teal | 5.73:1 | 7.15:1 |
| Deep teal | 8.85:1 | 11.08:1 |
| Checkpoint green | 4.87:1 | 9.38:1 |
| Ink | 16.84:1 | 16.38:1 |
| Slate | 7.16:1 | 9.71:1 |

These calculations support the exact pairs above; they do not prove every rendered component. Retest after opacity, material, image, disabled-state, or background changes.

Normal app surfaces should prefer iOS semantic colors. Brand colors must not replace system warning/error colors. Never communicate condition, severity, restriction, or completion by color alone.

## Typography and lockup

- Use Apple system typography through SwiftUI text styles.
- Typeset `AssetRounds` using a strong system title weight.
- Use `Field Inspections` as a smaller secondary descriptor only where the broad identity needs explanation.
- Use the current vertical name in metadata, feature headings, onboarding copy, and reports.
- Keep all wordmarks as live text in the app so Dynamic Type and localization remain possible.
- Do not place the descriptor or vertical name inside the app icon.

The presentation board in `SourceReference` is a relationship reference, not production wordmark artwork.

## App-icon rules

- Default: opaque 1024-pixel source.
- Dark: transparent background; system background visible.
- Tinted: true grayscale source.
- Keep identical geometry across appearances.
- Let the system apply the final mask and appearance treatment.
- Do not add a sign, light, playground, fire, HVAC, count badge, text, border, or baked rounded corner.
- The supplied 32-pixel sheet is an internal legibility check, not device proof.
- Before release, inspect Default, Dark, Tinted, generated Clear appearances, Settings, Search, notifications, and small Home Screen contexts on the supported OS.

## Reusable symbol rules

The package contains full-color, deep-teal one-color, and white/reversed transparent masters plus original and template Xcode image sets.

Use the mark sparingly in onboarding, About, a restrained empty state, export cover, website header, or report cover. Do not repeat it on every card.

Accessibility semantics:

- Decorative mark beside visible `AssetRounds` text: hide the image from accessibility.
- Meaningful standalone mark that acts as a control: supply the concise label `AssetRounds` plus the action or destination in the control label.
- Never expose the filename, `orbit`, `waypoint`, or visual metaphor as the VoiceOver label.

Maintain clear space equal to at least one quarter of the center circle's diameter. Do not rotate, skew, close the orbit, move the waypoint, independently recolor pieces, or attach a vertical badge.

The current masters are raster. A future reviewed vector may be created for print or large physical use, but it must trace the approved geometry and is not required for the iOS runtime package.

## Field interface language

- One obvious primary action per screen.
- Large, reachable actions for starting a check and capturing evidence.
- Opaque, high-contrast surfaces for outdoor readability.
- Evidence photos remain beside their finding and in a deterministic order.
- Preserve visible draft/saved state and recovery; never imply sync because the application Foundation & Build Plan V4 is device-local.
- Prefer truthful language such as `Saved on this iPhone`, `Backup created`, and `Export complete` only when the app proves those states.
- Respect Dynamic Type, Increase Contrast, VoiceOver, Reduce Motion, Dark Mode, and color differentiation.
- Use SF Symbols for familiar actions. Do not create branded substitutes for camera, share, settings, warning, navigation, or document actions.
- No permanent textures or ornamental motion behind working inspection screens.

## S10 semantic component contract

S10.2 may create a shared component only when S10.1 proves that the same visual/semantic role occurs on at least two released surfaces. Components describe presentation, not product behavior.

Required semantic roles:

- Primary, secondary, destructive, and quiet actions.
- Evidence card, photo thumbnail, state label, section heading, field surface, empty state, and report-brand header.
- Saved/draft/backup/export state that uses truthful device-local wording.
- Restriction, warning, destructive, unavailable, and completion states using text plus a distinct system symbol or shape—not color alone.
- Loading and disabled states that remain distinguishable in Light, Dark, Increase Contrast, and Differentiate Without Color.

All interactive targets must be at least 44 × 44 points. Ordinary work surfaces are opaque. On iOS 26, standard SwiftUI navigation and controls may adopt the system's current Liquid Glass appearance automatically; do not add custom decorative glass. On earlier supported systems, keep the native fallback. Reduce Transparency replaces any nonessential material with an opaque semantic surface.

## S10 common-task accessibility rule

Before AssetRounds declares an App Store accessibility feature, every common task listed in the frozen S10 matrix must be completable with that feature on every declared supported-device profile. Automated audits are required but do not replace actual VoiceOver, Voice Control, Larger Text, or field testing.

The S10 matrix must include first launch, primary inspection creation/completion, photo evidence, report use, work/recheck, backup/restore, purchase/restore/manage, settings, delete, and Erase All where those tasks exist in the released app.

## Localization and regression rule

- Keep user-facing copy in the app's localization system and avoid fixed-width text containers.
- Test English, Double-Length, Right-to-Left, Right-to-Left String, Tall, Accented, and Bounded pseudolanguages when the toolchain supports them.
- Every accepted visual baseline identifies the exact commit, fixture, device, OS, locale, appearance, content-size category, contrast/motion/transparency state, and source test.
- A baseline may change only with an explicit change record and human review. Never regenerate baselines merely to turn a failure green.

## Vertical-expansion rule

AssetRounds is one reliable inspection engine with specialized packs.

Each expansion may own exact nouns, prompts, evidence requirements, report sections, metadata, screenshots, and landing pages. Each expansion inherits the mark, color system, typography, navigation conventions, evidence behavior, issue → work → recheck history, accessibility, backup/export behavior, and report quality.

Custom Product Pages may eventually present different verticals with tailored screenshots and copy while retaining the same master icon. Do not advertise a vertical before its product experience is shipped and reviewable.

## Claims and trust boundaries

Do not claim cloud sync, teams, AI detection, compliance certification, instant reporting, tamper-proof records, or zero data loss unless the shipped app and evidence support the exact statement.

For the application Foundation & Build Plan V4, the safest trust language is device-local records, guided photo evidence, work/recheck history, backup/export, and generated reports—only after those flows pass their release evidence.

## Governance

This brand handoff is a design input, not repository authority. `AGENTS.md` and `docs/execution/CURRENT_TASK.md` still control allowed paths, branches, CI, and release actions. Every release must also pass the scoring hard gates; a high numerical score alone is insufficient.

Official references:

- https://developer.apple.com/documentation/xcode/configuring-your-app-icon/
- https://developer.apple.com/design/human-interface-guidelines/app-icons/
- https://developer.apple.com/design/human-interface-guidelines/accessibility/
- https://developer.apple.com/design/human-interface-guidelines/color/
- https://developer.apple.com/documentation/technologyoverviews/adopting-liquid-glass
- https://developer.apple.com/documentation/accessibility/performing-accessibility-audits-for-your-app
- https://developer.apple.com/help/app-store-connect/manage-app-accessibility/overview-of-accessibility-nutrition-labels/
