#requires -Version 7.0

param(
    [ValidateSet('Package', 'Inventory', 'ComponentSystem', 'Migration', 'AutomatedLab', 'PhysicalExperience', 'Release')]
    [string]$Mode = 'Package',
    [string]$ActivationPath,
    [string]$StageCheckpointsPath,
    [string]$InventoryPath,
    [string]$AccessibilityPath,
    [string]$TokenCoveragePath,
    [string]$RegressionPath,
    [string]$ExperiencePath,
    [string]$StoreReadinessPath,
    [string]$EvidenceLockPath,
    [string]$RepositoryRoot,
    [string]$TokenCatalogPath,
    [string]$PackageZipPath
)

$ErrorActionPreference = 'Stop'
$packageRoot = Split-Path -Parent $PSScriptRoot
$handoffRoot = Join-Path $packageRoot 'Handoff'
$schemaValidator = Join-Path $PSScriptRoot 'validate-json-schema-subset.py'
$errors = [System.Collections.Generic.List[string]]::new()

function Add-Error([string]$Message) { [void]$errors.Add($Message) }
function Read-Json([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { Add-Error "Missing JSON: $Path"; return $null }
    try { return Get-Content -Raw -LiteralPath $Path | ConvertFrom-Json -Depth 100 }
    catch { Add-Error "Invalid JSON $Path`: $($_.Exception.Message)"; return $null }
}
function Test-Placeholder([object]$Value) { return ([string]$Value).StartsWith('REQUIRED_') }
function Assert-ExactSet([object[]]$Expected, [object[]]$Actual, [string]$Label) {
    $a = @($Expected | ForEach-Object { [string]$_ } | Sort-Object -Unique)
    $b = @($Actual | ForEach-Object { [string]$_ } | Sort-Object -Unique)
    if (($a -join "`n") -ne ($b -join "`n")) { Add-Error "$Label set mismatch; expected=[$($a -join ', ')], actual=[$($b -join ', ')]." }
}
function Assert-Unique([object[]]$Rows, [string]$Property, [string]$Label) {
    $values = @($Rows | ForEach-Object { [string]($_.$Property) })
    foreach ($group in @($values | Group-Object | Where-Object { [string]::IsNullOrWhiteSpace($_.Name) -or $_.Count -gt 1 })) { Add-Error "$Label has blank/duplicate $Property '$($group.Name)'." }
}
function Invoke-Schema([string]$Name, [string]$InstancePath) {
    $schemaPath = Join-Path $handoffRoot "$Name.schema.json"
    $output = & python $schemaValidator --schema $schemaPath --instance $InstancePath 2>&1
    if ($LASTEXITCODE -ne 0) { Add-Error "Schema validation failed for $InstancePath`: $($output -join '; ')" }
}
function Assert-PassRows([object[]]$Rows, [string]$StatusProperty, [string]$Label, [string[]]$Allowed = @('PASS')) {
    foreach ($row in @($Rows)) {
        if ($Allowed -notcontains [string]($row.$StatusProperty)) { Add-Error "$Label contains non-accepted $StatusProperty '$($row.$StatusProperty)'." }
    }
}
function Get-HistoricalBlobSha([string]$Root, [string]$Commit, [string]$Path) {
    $code = 'import hashlib,subprocess,sys; p=subprocess.run(["git","-C",sys.argv[1],"show",sys.argv[2]+":"+sys.argv[3]],stdout=subprocess.PIPE,stderr=subprocess.PIPE); sys.exit(p.returncode) if p.returncode else print(hashlib.sha256(p.stdout).hexdigest().upper())'
    $value = & python -c $code $Root $Commit $Path 2>$null
    if ($LASTEXITCODE -ne 0) { return $null }
    return ([string]$value).Trim()
}
function Get-CanonicalJsonSha([object]$Value) {
    $json = $Value | ConvertTo-Json -Depth 100 -Compress
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($json)
    return [Convert]::ToHexString([System.Security.Cryptography.SHA256]::HashData($bytes))
}

$names = @('s10-activation', 's10-stage-checkpoints', 's10-screen-state-inventory', 's10-accessibility-common-tasks', 's10-token-coverage', 's10-visual-regression', 's10-experience-validation', 's10-store-readiness', 's10-evidence-lock')
$parameters = @{
    's10-activation' = $ActivationPath; 's10-stage-checkpoints' = $StageCheckpointsPath; 's10-screen-state-inventory' = $InventoryPath
    's10-accessibility-common-tasks' = $AccessibilityPath; 's10-token-coverage' = $TokenCoveragePath; 's10-visual-regression' = $RegressionPath
    's10-experience-validation' = $ExperiencePath; 's10-store-readiness' = $StoreReadinessPath; 's10-evidence-lock' = $EvidenceLockPath
}
$documents = @{}
foreach ($name in $names) {
    $path = if ($Mode -eq 'Package') { Join-Path $handoffRoot "$name.template.json" } else { [string]$parameters[$name] }
    if ([string]::IsNullOrWhiteSpace($path)) { Add-Error "-$($name.Replace('s10-', '').Replace('-', ''))Path (the canonical $name.json) is required in $Mode mode."; continue }
    Invoke-Schema $name $path
    $documents[$name] = Read-Json $path
}

$activation = $documents['s10-activation']
$stages = $documents['s10-stage-checkpoints']
$inventory = $documents['s10-screen-state-inventory']
$a11y = $documents['s10-accessibility-common-tasks']
$tokens = $documents['s10-token-coverage']
$visual = $documents['s10-visual-regression']
$experience = $documents['s10-experience-validation']
$store = $documents['s10-store-readiness']
$lock = $documents['s10-evidence-lock']

if ($null -ne $activation) {
    $canonical = [ordered]@{
        activation = 'docs/design/s10/s10-activation.json'; stage_checkpoints = 'docs/design/s10/s10-stage-checkpoints.json'
        screen_state_inventory = 'docs/design/s10/s10-screen-state-inventory.json'; accessibility_common_tasks = 'docs/design/s10/s10-accessibility-common-tasks.json'
        token_coverage = 'docs/design/s10/s10-token-coverage.json'; visual_regression = 'docs/design/s10/s10-visual-regression.json'
        experience_validation = 'docs/design/s10/s10-experience-validation.json'; store_readiness = 'docs/design/s10/s10-store-readiness.json'
        evidence_lock = 'docs/design/s10/s10-evidence-lock.json'
    }
    foreach ($entry in $canonical.GetEnumerator()) { if ([string]$activation.contract_paths.($entry.Key) -ne $entry.Value) { Add-Error "Noncanonical contract path for $($entry.Key)." } }
    Assert-ExactSet @('S10.1','S10.2','S10.3','S10.4','S10.5','S10.6') @($activation.cards.card_id) 'Activation cards'
    Assert-ExactSet @('Inventory','ComponentSystem','Migration','AutomatedLab','PhysicalExperience','Release') @($activation.expected_checkpoint_stages) 'Checkpoint stages'
    Assert-ExactSet @('double_length','rtl','rtl_string','tall','accented','bounded') @($activation.required_pseudolanguages) 'Pseudolanguages'
    Assert-ExactSet @('voiceover','voice_control','larger_text','dark_interface','differentiate_without_color','sufficient_contrast','reduced_motion') @($activation.accessibility_features) 'Accessibility features'
    if ($Mode -ne 'Package') {
        if ($activation.document_status -ne 'frozen') { Add-Error 'Activation must be frozen after Package mode.' }
        if (($activation | ConvertTo-Json -Depth 100 -Compress) -cmatch '"REQUIRED_[A-Z0-9_]+') { Add-Error 'Frozen activation contains an unresolved REQUIRED_* placeholder.' }
        if (-not $activation.rights_attestation.grant_accepted) { Add-Error 'Owner rights/use grant has not been accepted.' }
        if (Test-Placeholder $activation.package_integrity.zip_sha256) { Add-Error 'Final package ZIP SHA-256 is not hydrated.' }
        if (Test-Placeholder $activation.package_integrity.asset_manifest_sha256) { Add-Error 'Asset-manifest SHA-256 is not hydrated.' }
        $manifestSha = (Get-FileHash -Algorithm SHA256 -LiteralPath (Join-Path $packageRoot 'asset-manifest.json')).Hash
        if ($activation.package_integrity.asset_manifest_sha256 -ne $manifestSha) { Add-Error 'Activation asset-manifest SHA-256 does not match this package.' }
        if ([string]::IsNullOrWhiteSpace($PackageZipPath) -or -not (Test-Path -LiteralPath $PackageZipPath -PathType Leaf)) { Add-Error 'Hydrated modes require -PackageZipPath for final ZIP-byte verification.' }
        elseif ((Get-FileHash -Algorithm SHA256 -LiteralPath $PackageZipPath).Hash -ne $activation.package_integrity.zip_sha256) { Add-Error 'Activation ZIP SHA-256 does not match -PackageZipPath.' }
        if ($activation.publication_state -eq 'published' -and $activation.activation_route -ne 'post_release_update') { Add-Error 'Published route must be post_release_update.' }
        if ($activation.publication_state -eq 'unpublished' -and $activation.activation_route -ne 'replace_unpublished_candidate') { Add-Error 'Unpublished route must be replace_unpublished_candidate.' }
        if ($activation.activation_route -eq 'post_release_update' -and [string]::IsNullOrWhiteSpace($activation.s9_authority.published_release_evidence_id)) { Add-Error 'Published route needs published-release evidence.' }
        if ($activation.activation_route -eq 'replace_unpublished_candidate' -and [string]::IsNullOrWhiteSpace($activation.s9_authority.unpublished_candidate_evidence_id)) { Add-Error 'Unpublished replacement route needs candidate evidence.' }
        if (@($activation.device_profile_ids).Count -lt 2 -or @($activation.release_locale_profile_ids).Count -lt 1) { Add-Error 'Activation needs at least two device profiles and one release locale profile.' }
        foreach ($card in @($activation.cards)) {
            if (@($card.allowed_paths).Count -eq 0 -or (Test-Placeholder $card.branch) -or (Test-Placeholder $card.selector_sha256)) { Add-Error "$($card.card_id) authority is not hydrated." }
            foreach ($allowedPath in @($card.allowed_paths)) { if ($allowedPath -match '(^/|\\|:|\*|\?|\[|\]|(^|/)\.\.(/|$))' -or $allowedPath.EndsWith('/')) { Add-Error "$($card.card_id) allowed path is not an exact forward-slash file path: $allowedPath" } }
            $tier = [string]$card.selector.tier
            $expected = if ($tier -eq 'N8') { @(300,600,900,0,2400,$false) } elseif ($tier -eq 'P12') { @(300,600,900,900,3300,$true) } elseif ($tier -eq 'F25') { @(300,900,1200,1800,4500,$true) } else { $null }
            if ($null -eq $expected) { Add-Error "$($card.card_id) selector tier is invalid." }
            elseif ((@($card.selector.setup_timeout_seconds,$card.selector.build_timeout_seconds,$card.selector.test_timeout_seconds,$card.selector.ui_timeout_seconds,$card.selector.total_timeout_seconds,$card.selector.run_ui_smoke) -join '|') -ne ($expected -join '|')) { Add-Error "$($card.card_id) selector does not match its tier." }
            if (-not (Test-Placeholder $card.selector_sha256) -and $card.selector_sha256 -ne (Get-CanonicalJsonSha $card.selector)) { Add-Error "$($card.card_id) selector SHA-256 does not match its canonical compact JSON." }
            if ($card.card_id -eq 'S10.2') {
                $assetPaths = @(
                    'FieldEvidenceApp/Resources/Assets.xcassets/AppIcon.appiconset/AppIcon-Default-1024.png',
                    'FieldEvidenceApp/Resources/Assets.xcassets/AppIcon.appiconset/AppIcon-Dark-1024.png',
                    'FieldEvidenceApp/Resources/Assets.xcassets/AppIcon.appiconset/AppIcon-Tinted-1024.png',
                    'FieldEvidenceApp/Resources/Assets.xcassets/AppIcon.appiconset/Contents.json',
                    'FieldEvidenceApp/Resources/Assets.xcassets/AssetRoundsBrandSymbol.imageset/AssetRoundsBrandSymbol-1x.png',
                    'FieldEvidenceApp/Resources/Assets.xcassets/AssetRoundsBrandSymbol.imageset/AssetRoundsBrandSymbol-2x.png',
                    'FieldEvidenceApp/Resources/Assets.xcassets/AssetRoundsBrandSymbol.imageset/AssetRoundsBrandSymbol-3x.png',
                    'FieldEvidenceApp/Resources/Assets.xcassets/AssetRoundsBrandSymbol.imageset/Contents.json',
                    'FieldEvidenceApp/Resources/Assets.xcassets/AssetRoundsBrandSymbolTemplate.imageset/AssetRoundsBrandSymbolTemplate-1x.png',
                    'FieldEvidenceApp/Resources/Assets.xcassets/AssetRoundsBrandSymbolTemplate.imageset/AssetRoundsBrandSymbolTemplate-2x.png',
                    'FieldEvidenceApp/Resources/Assets.xcassets/AssetRoundsBrandSymbolTemplate.imageset/AssetRoundsBrandSymbolTemplate-3x.png',
                    'FieldEvidenceApp/Resources/Assets.xcassets/AssetRoundsBrandSymbolTemplate.imageset/Contents.json',
                    'FieldEvidenceApp.xcodeproj/project.pbxproj'
                )
                foreach ($assetPath in $assetPaths) { if (@($card.allowed_paths) -notcontains $assetPath) { Add-Error "S10.2 does not authorize required integration path $assetPath." } }
            }
        }
    }
}

if ($Mode -eq 'Package') {
    foreach ($name in $names) { if ($null -ne $documents[$name] -and $documents[$name].document_status -ne 'template') { Add-Error "$name package artifact is not a template." } }
} else {
    if ([string]::IsNullOrWhiteSpace($RepositoryRoot) -or -not (Test-Path -LiteralPath $RepositoryRoot -PathType Container)) { Add-Error 'Hydrated modes require an existing -RepositoryRoot for ancestry and historical-blob checks.' }
    $stageOrder = @('Inventory','ComponentSystem','Migration','AutomatedLab','PhysicalExperience','Release')
    $stageCount = [Array]::IndexOf($stageOrder, $Mode) + 1
    if ($stages.receipt_model -ne 'E_product_K_evidence_C_receipt') { Add-Error 'Stage receipt model is not E/K/C.' }
    if (($Mode -eq 'Release' -and $stages.document_status -ne 'release_locked') -or ($Mode -ne 'Release' -and $stages.document_status -ne 'tracking')) { Add-Error "$Mode has the wrong stage-checkpoint document status." }
    if (@($stages.checkpoints).Count -ne $stageCount) { Add-Error "$Mode requires exactly $stageCount stage checkpoints." }
    else { for ($i=0; $i -lt $stageCount; $i++) { if ($stages.checkpoints[$i].stage -ne $stageOrder[$i]) { Add-Error "Checkpoint $i is not $($stageOrder[$i])." } } }
    foreach ($row in @($stages.checkpoints)) {
        if ($row.evidence_head_role -ne 'K') { Add-Error "$($row.stage) evidence head role must be K." }
        if (@($row.documents).Count -eq 0 -or @($row.evidence_ids).Count -eq 0) { Add-Error "$($row.stage) checkpoint lacks documents or evidence IDs." }
        if ($null -ne $RepositoryRoot -and (Test-Path -LiteralPath $RepositoryRoot -PathType Container)) {
            & git -C $RepositoryRoot merge-base --is-ancestor $row.product_head $row.evidence_head 2>$null
            if ($LASTEXITCODE -ne 0) { Add-Error "$($row.stage) product head E is not an ancestor of evidence head K." }
            foreach ($doc in @($row.documents)) { $sha = Get-HistoricalBlobSha $RepositoryRoot $doc.blob_commit $doc.path; if ($null -eq $sha -or $sha -ne $doc.sha256) { Add-Error "$($row.stage) historical blob hash mismatch: $($doc.path)." } }
        }
    }
    if ($stageCount -ge 2) {
        $componentReceipt = $stages.checkpoints[1]
        foreach ($requiredEvidence in @('appicon-primary-build-setting','runtime-asset-count-12')) { if (@($componentReceipt.evidence_ids) -notcontains $requiredEvidence) { Add-Error "ComponentSystem lacks required evidence ID $requiredEvidence." } }
        if ($tokens.component_system_product_head -ne $componentReceipt.product_head) { Add-Error 'Component-system token head does not match its checkpoint product E.' }
    }
    if ($stageCount -ge 3) {
        if ($tokens.migration_product_head -ne $stages.checkpoints[2].product_head -or $experience.product_head -ne $stages.checkpoints[2].product_head) { Add-Error 'Migration/token/experience product E values do not match.' }
    }
    if (@($inventory.routes).Count -eq 0 -or @($inventory.fixtures).Count -eq 0 -or @($inventory.device_profiles).Count -lt 2) { Add-Error 'Frozen inventory needs routes, fixtures, and at least two device profiles.' }
    if ($a11y.document_status -eq 'template' -or @($a11y.tasks).Count -eq 0) { Add-Error 'Accessibility common tasks are not frozen.' }
    if ($experience.document_status -eq 'template' -or @($experience.plan.required_common_task_ids).Count -eq 0) { Add-Error 'Experience plan is not hydrated.' }
    Assert-ExactSet @($a11y.tasks.task_id) @($experience.plan.required_common_task_ids) 'Experience/common tasks'
    $stateIds = @($inventory.routes | ForEach-Object { $_.states } | ForEach-Object { $_.state_id })
    Assert-Unique @($inventory.routes | ForEach-Object { $_.states }) 'state_id' 'Inventory states'
    Assert-ExactSet $stateIds @($tokens.coverage.screen_state_id) 'Token screen coverage'
    Assert-ExactSet $stateIds @($visual.baselines.screen_state_id) 'Visual baseline state coverage'
    foreach ($task in @($a11y.tasks)) {
        $expectedCombinations = foreach ($profile in @($a11y.device_profile_ids)) { foreach ($feature in @($a11y.features)) { "$profile|$feature" } }
        $actualCombinations = @($task.feature_results | ForEach-Object { "$($_.device_profile_id)|$($_.feature)" })
        Assert-ExactSet $expectedCombinations $actualCombinations "Accessibility coverage for $($task.task_id)"
    }
    if ($store.document_status -eq 'template' -or @($store.plan.screenshot_slots).Count -eq 0) { Add-Error 'Store plan is not hydrated with screenshot slots.' }
    Assert-ExactSet @($activation.release_locale_profile_ids) @($store.plan.release_locale_profile_ids) 'Release locale profiles'
    foreach ($document in @($stages,$experience,$store)) { if ($document.activation_id -ne $activation.activation_id) { Add-Error 'Cross-contract activation_id mismatch.' } }
}

if ($Mode -in @('Inventory')) {
    if ($tokens.document_status -ne 'planned') { Add-Error 'Inventory requires planned token coverage.' }
    if ($visual.document_status -ne 'baseline_frozen') { Add-Error 'Inventory requires frozen visual baselines.' }
    foreach ($row in @($visual.baselines)) { if (-not [string]::IsNullOrWhiteSpace($row.candidate_product_head) -or $row.result -ne 'NOT_RUN' -or $row.review_status -ne 'NOT_REVIEWED') { Add-Error "Inventory baseline $($row.baseline_id) promotes candidate evidence early." } }
}
if ($Mode -in @('ComponentSystem')) {
    if ($tokens.document_status -ne 'components_implemented') { Add-Error 'ComponentSystem requires components_implemented.' }
    Assert-PassRows @($tokens.components) 'status' 'Components'
    Assert-PassRows @($tokens.coverage) 'status' 'Unmigrated coverage' @('NOT_RUN')
}
if ($Mode -in @('Migration','AutomatedLab','PhysicalExperience','Release')) {
    if ($tokens.document_status -ne 'migrated' -or $tokens.untracked_visual_constant_count -ne 0) { Add-Error 'Migration requires migrated coverage and zero untracked visual constants.' }
    Assert-PassRows @($tokens.components) 'status' 'Components'; Assert-PassRows @($tokens.coverage) 'status' 'Screen coverage'
}
if ($Mode -in @('AutomatedLab','PhysicalExperience','Release')) {
    if ($a11y.document_status -notin @('automated_evaluated','evaluated')) { Add-Error 'AutomatedLab requires automated accessibility evaluation.' }
    foreach ($task in @($a11y.tasks)) { foreach ($row in @($task.feature_results)) {
        if ($row.automated_status -notin @('PASS','NOT_APPLICABLE','EXCEPTION')) { Add-Error "Automated accessibility is open for $($task.task_id)/$($row.feature)/$($row.device_profile_id)." }
        if ($row.automated_status -eq 'PASS' -and (@($row.automated_evidence_ids).Count -eq 0 -or [string]::IsNullOrWhiteSpace($row.automated_reviewer))) { Add-Error "Automated accessibility PASS lacks evidence/reviewer for $($task.task_id)/$($row.feature)/$($row.device_profile_id)." }
        if ($row.automated_status -eq 'EXCEPTION' -and ([string]::IsNullOrWhiteSpace($row.exception_issue_id) -or [string]::IsNullOrWhiteSpace($row.exception_owner) -or $row.exception_expires_at -notmatch '^\d{4}-\d{2}-\d{2}$' -or [string]::IsNullOrWhiteSpace($row.exception_rationale))) { Add-Error 'Accessibility exception lacks issue, owner, expiry, or rationale.' }
    } }
    if ($visual.document_status -ne 'automated_evaluated') { Add-Error 'AutomatedLab requires evaluated visual regression.' }
    Assert-PassRows @($visual.baselines) 'result' 'Visual baselines'; Assert-PassRows @($visual.baselines) 'review_status' 'Visual human review' @('APPROVED')
    foreach ($row in @($visual.baselines)) { if ($row.candidate_product_head -ne $experience.product_head) { Add-Error "Visual candidate $($row.baseline_id) is not tied to migrated product E." } }
}
if ($Mode -in @('PhysicalExperience','Release')) {
    if ($a11y.document_status -ne 'evaluated') { Add-Error 'PhysicalExperience requires manual accessibility evaluation.' }
    foreach ($task in @($a11y.tasks)) { foreach ($row in @($task.feature_results)) {
        if ($row.manual_status -notin @('PASS','NOT_APPLICABLE')) { Add-Error "Manual accessibility is open for $($task.task_id)/$($row.feature)/$($row.device_profile_id)." }
        if ($row.manual_status -eq 'PASS' -and (@($row.manual_evidence_ids).Count -eq 0 -or [string]::IsNullOrWhiteSpace($row.manual_reviewer))) { Add-Error "Manual accessibility PASS lacks evidence/reviewer for $($task.task_id)/$($row.feature)/$($row.device_profile_id)." }
    } }
    if ($experience.document_status -ne 'evaluated' -or $experience.severe_issue_count -ne 0) { Add-Error 'PhysicalExperience requires evaluated evidence and zero severe issues.' }
    if (@($experience.physical_sessions).Count -lt 5 -or @($experience.physical_sessions.role_id | Sort-Object -Unique).Count -lt 3) { Add-Error 'Physical experience lacks five sessions across three roles.' }
    Assert-ExactSet @('daylight','low_light') @($experience.physical_sessions.lighting_condition) 'Physical lighting'
    Assert-ExactSet @($experience.plan.device_profile_ids) @($experience.physical_sessions.device_profile_id) 'Physical device profiles'
    Assert-ExactSet @($experience.plan.required_common_task_ids) @($experience.physical_sessions.common_task_ids) 'Physical common tasks'
    Assert-ExactSet @($experience.plan.required_scenario_ids) @($experience.physical_sessions.scenario_ids) 'Physical scenarios'
    foreach ($session in @($experience.physical_sessions)) { if ($session.status -ne 'PASS' -or $session.installed_product_head -ne $experience.product_head -or $session.distribution_route -ne $activation.physical_device_bridge.distribution_route -or [string]::IsNullOrWhiteSpace($session.installation_evidence_id)) { Add-Error "Physical session $($session.session_id) is not a verified activated-route install of product E." } }
    Assert-ExactSet @($experience.plan.required_durability_families) @($experience.durability_results.check_id) 'Durability families'
    Assert-PassRows @($experience.durability_results) 'status' 'Durability' @('PASS','NOT_APPLICABLE')
    foreach ($row in @($experience.durability_results | Where-Object { $_.status -eq 'NOT_APPLICABLE' })) { $planRow = @($experience.plan.durability_checks | Where-Object { $_.check_id -eq $row.check_id }); if ($planRow.Count -ne 1 -or $planRow[0].applicability -ne 'not_applicable_at_s9') { Add-Error "Durability NOT_APPLICABLE was not frozen at S9: $($row.check_id)." } }
    Assert-ExactSet @($experience.plan.required_performance_families) @($experience.performance_results.metric_family) 'Performance families'
    Assert-PassRows @($experience.performance_results) 'status' 'Performance'
    foreach ($row in @($experience.performance_results)) {
        if ($row.status -eq 'PASS' -and (($row.operator -eq 'less_than_or_equal' -and $row.measured_value -gt $row.threshold) -or ($row.operator -eq 'greater_than_or_equal' -and $row.measured_value -lt $row.threshold))) { Add-Error "Performance PASS contradicts threshold for $($row.metric_id)." }
    }
}
if ($Mode -eq 'Release') {
    if ((@($stages,$inventory,$a11y,$tokens,$visual,$experience,$store,$lock) | ConvertTo-Json -Depth 100 -Compress) -cmatch '"REQUIRED_[A-Z0-9_]+') { Add-Error 'Release contracts contain an unresolved REQUIRED_* placeholder.' }
    if ($store.document_status -ne 'release_locked' -or $store.final_product_head -ne $lock.final_product_head) { Add-Error 'Store readiness is not locked to final product E.' }
    if ($lock.document_status -ne 'release_locked' -or $lock.receipt_model -ne 'E_product_K_evidence_C_receipt') { Add-Error 'Evidence lock is not release_locked with E/K/C semantics.' }
    if ($activation.rights_attestation.trademark_clearance_status -ne 'CLEARED' -or [string]::IsNullOrWhiteSpace($activation.rights_attestation.trademark_evidence_id)) { Add-Error 'Release requires explicit trademark-clearance evidence.' }
    $releaseReceipt = $stages.checkpoints[5]
    if ($lock.final_product_head -ne $releaseReceipt.product_head -or $lock.release_evidence_head -ne $releaseReceipt.evidence_head) { Add-Error 'Evidence lock does not match the Release E/K checkpoint.' }
    foreach ($property in @('toolchain_id','runner_image','xcode_version','xcode_build','sdk_name','sdk_build','swift_version','build_configuration')) { if ([string]$store.toolchain.$property -ne [string]$activation.toolchain.$property) { Add-Error "Store toolchain differs from activation at $property." } }
    Assert-ExactSet @($store.plan.privacy_gate_ids) @($store.privacy_results.gate_id) 'Privacy gates'
    Assert-ExactSet @($store.plan.appearance_gate_ids) @($store.appearance_results.gate_id) 'Appearance gates'
    Assert-ExactSet @($store.plan.accessibility_label_gate_ids) @($store.accessibility_labels.gate_id) 'Accessibility-label gates'
    Assert-ExactSet @($store.plan.app_tag_gate_ids) @($store.app_tags.gate_id) 'App Tag gates'
    Assert-ExactSet @($store.plan.sdk_gate_ids) @($store.sdk_inventory.gate_id) 'SDK gates'
    Assert-ExactSet @($store.plan.platform_device_profile_ids) @($store.platform_compatibility.device_profile_id) 'Platform profiles'
    Assert-ExactSet @($store.plan.legal_url_gate_ids) @($store.legal_urls.gate_id) 'Legal URL gates'
    foreach ($localeProfileId in @($store.plan.release_locale_profile_ids)) { if (@($store.localization_metadata.locale_profile_id) -notcontains $localeProfileId) { Add-Error "Localization metadata is missing release locale $localeProfileId." } }
    Assert-PassRows @($store.privacy_results) 'status' 'Privacy'; Assert-PassRows @($store.appearance_results) 'status' 'Appearance'; Assert-PassRows @($store.accessibility_labels) 'status' 'Accessibility labels' @('PASS','NOT_AVAILABLE'); Assert-PassRows @($store.localization_metadata) 'status' 'Localization metadata'; Assert-PassRows @($store.sdk_inventory) 'status' 'SDK inventory'; Assert-PassRows @($store.platform_compatibility) 'status' 'Platform compatibility'; Assert-PassRows @($store.legal_urls) 'status' 'Legal URLs'; Assert-PassRows @($store.screenshots) 'status' 'Screenshots'; Assert-PassRows @($store.claims) 'status' 'Claims'
    Assert-PassRows @($store.app_tags) 'status' 'App Tags' @('PASS','NOT_AVAILABLE')
    foreach ($record in @($store.archive_privacy_report,$store.platform_compatibility_escape,$store.age_rating)) { if ($record.status -ne 'PASS' -or @($record.evidence_ids).Count -eq 0 -or [string]::IsNullOrWhiteSpace($record.reviewer)) { Add-Error "Release singleton gate $($record.gate_id) is not a fully evidenced PASS." } }
    if ($store.platform_compatibility_escape.uidesign_requires_compatibility_present) { Add-Error 'UIDesignRequiresCompatibility remains present.' }
    foreach ($record in @($store.custom_product_pages,$store.ppo_experiments)) { if ($record.status -notin @('PASS','NOT_AVAILABLE') -or @($record.evidence_ids).Count -eq 0 -or [string]::IsNullOrWhiteSpace($record.reviewer)) { Add-Error "Optional store gate $($record.gate_id) lacks a final evidenced disposition." } }
    if (@($store.toolchain.evidence_ids).Count -eq 0) { Add-Error 'Final toolchain lacks evidence IDs.' }
    foreach ($shot in @($store.screenshots)) { if ($shot.source_product_head -ne $lock.final_product_head -or $shot.has_alpha -or $shot.apple_specification_url -notmatch '^https://([A-Za-z0-9-]+\.)*apple\.com/' -or $shot.apple_specification_checked_date -notmatch '^\d{4}-\d{2}-\d{2}$') { Add-Error "Screenshot $($shot.screenshot_id) lacks exact product/Apple specification provenance or contains alpha." } }
    foreach ($group in @($store.screenshots | Group-Object device_class,locale_profile_id)) {
        $ordered = @($group.Group | Sort-Object slot_order)
        if (@($ordered.slot_order | Sort-Object -Unique).Count -ne $ordered.Count -or @($ordered | Where-Object { $_.slot_order -lt 1 -or $_.slot_order -gt 10 }).Count -gt 0) { Add-Error "Screenshot group $($group.Name) has invalid/duplicate slot order." }
        if ($ordered.Count -lt 3 -or (@($ordered[0].story_role,$ordered[1].story_role,$ordered[2].story_role) -join '|') -ne 'find_asset|capture_evidence|share_report') { Add-Error "Screenshot group $($group.Name) does not use the required first-three story order." }
    }
    Assert-ExactSet @($store.plan.screenshot_slots.slot_id) @($store.screenshots.slot_id) 'Planned/actual screenshot slots'
    foreach ($shot in @($store.screenshots)) {
        $planned = @($store.plan.screenshot_slots | Where-Object { $_.slot_id -eq $shot.slot_id })
        if ($planned.Count -ne 1) { continue }
        foreach ($property in @('gate_id','slot_order','story_role','device_class','device_profile_id','locale_profile_id','orientation','pixel_width','pixel_height','apple_specification_url','apple_specification_checked_date')) { if ([string]$shot.$property -ne [string]$planned[0].$property) { Add-Error "Screenshot $($shot.screenshot_id) differs from its frozen slot property $property." } }
    }
    foreach ($documentType in @('asset_manifest','activation','stage_checkpoints','screen_state_inventory','accessibility_common_tasks','token_coverage','visual_regression','experience_validation','store_readiness','release_validation_matrix','ci_artifact_index','owner_approval')) { if (@($lock.documents.document_type) -notcontains $documentType) { Add-Error "Evidence lock is missing required document type $documentType." } }
    if (@($lock.ci_runs | Where-Object { $_.conclusion -eq 'success' -and $_.head_sha -eq $lock.final_product_head }).Count -eq 0) { Add-Error 'No successful exact-product-head release CI run is locked.' }
    if ($null -ne $RepositoryRoot -and (Test-Path -LiteralPath $RepositoryRoot -PathType Container)) {
        & git -C $RepositoryRoot merge-base --is-ancestor $lock.final_product_head $lock.release_evidence_head 2>$null
        if ($LASTEXITCODE -ne 0) { Add-Error 'Final product E is not an ancestor of release evidence K.' }
        foreach ($doc in @($lock.documents)) { $sha = Get-HistoricalBlobSha $RepositoryRoot $doc.blob_commit $doc.path; if ($null -eq $sha -or $sha -ne $doc.sha256) { Add-Error "Evidence-lock historical blob hash mismatch: $($doc.path)." } }
    }
}

if ($errors.Count -gt 0) { foreach ($validationError in $errors) { Write-Error $validationError }; exit 1 }
Write-Output "PASS: AssetRounds S10 V4.1 contracts ($Mode)."
