# Brand Handoff V4.1 validation tools

Use PowerShell 7 (`pwsh.exe`) and Python 3.

```powershell
pwsh.exe -NoProfile -File .\Tools\validate-brand-handoff.ps1
pwsh.exe -NoProfile -File .\Tools\validate-s10-contracts.ps1 -Mode Package
```

Package validation checks the manifest inventory/lengths/hashes, strict JSON and schema/template conformance, score/status, approved image dimensions/alpha/grayscale/catalog references, required files, LF/no-BOM policy, and Package lifecycle. It proves no target result.

For hydrated repository modes, supply all nine exact canonical paths plus `-RepositoryRoot <repo>` and `-PackageZipPath <final-distributed.zip>`:

```text
docs/design/s10/s10-activation.json
docs/design/s10/s10-stage-checkpoints.json
docs/design/s10/s10-screen-state-inventory.json
docs/design/s10/s10-accessibility-common-tasks.json
docs/design/s10/s10-token-coverage.json
docs/design/s10/s10-visual-regression.json
docs/design/s10/s10-experience-validation.json
docs/design/s10/s10-store-readiness.json
docs/design/s10/s10-evidence-lock.json
```

Run exactly one stage mode: `Inventory`, `ComponentSystem`, `Migration`, `AutomatedLab`, `PhysicalExperience`, or `Release`. Each requires its own ordered checkpoint row. ComponentSystem accepts isolated component PASS with screen coverage still `NOT_RUN`; Migration requires screen PASS; AutomatedLab does not require manual sessions; PhysicalExperience does. Release checks product E versus evidence K, historical Git blobs, store/compliance evidence, rights/clearance, and exact-E CI.

The validators never replace repository authority, Xcode/macOS CI, Simulator, physical devices, legal review, App Store Connect, signing, upload, or owner evidence.
