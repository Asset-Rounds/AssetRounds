"""Strictly parse JSON files and reject exact duplicate object keys."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any


class DuplicateKeyError(ValueError):
    pass


def reject_duplicate_keys(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise DuplicateKeyError(f"duplicate property {key!r}")
        result[key] = value
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("paths", nargs="+", type=Path)
    args = parser.parse_args()

    for path in args.paths:
        try:
            with path.open("r", encoding="utf-8") as handle:
                json.load(handle, object_pairs_hook=reject_duplicate_keys)
        except (OSError, UnicodeError, json.JSONDecodeError, DuplicateKeyError) as exc:
            print(f"ERROR: {path}: {exc}", file=sys.stderr)
            return 1

    print(f"PASS: strict JSON parse ({len(args.paths)} files)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
