#requires -Version 7.0

param([string]$PackageRoot = (Split-Path -Parent $PSScriptRoot))

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing
$errors = [System.Collections.Generic.List[string]]::new()
function Add-Error([string]$Message) { [void]$errors.Add($Message) }
function Read-Json([string]$Path) {
    try { return Get-Content -Raw -LiteralPath $Path | ConvertFrom-Json -Depth 100 }
    catch { Add-Error "Invalid JSON $Path`: $($_.Exception.Message)"; return $null }
}
function Test-Image([string]$Path, [int]$Width, [int]$Height, [ValidateSet('any','opaque','transparent')][string]$AlphaContract = 'any', [bool]$Grayscale = $false) {
    try { $bitmap = [System.Drawing.Bitmap]::FromFile($Path) } catch { Add-Error "Cannot load image $Path`: $($_.Exception.Message)"; return }
    try {
        if ($bitmap.Width -ne $Width -or $bitmap.Height -ne $Height) { Add-Error "Image dimensions differ for $Path." }
        if ($AlphaContract -ne 'any' -or $Grayscale) {
            $sawTransparent = $false
            for ($y = 0; $y -lt $bitmap.Height; $y++) {
                for ($x = 0; $x -lt $bitmap.Width; $x++) {
                    $pixel = $bitmap.GetPixel($x, $y)
                    if ($pixel.A -ne 255) { $sawTransparent = $true }
                    if ($Grayscale -and ($pixel.R -ne $pixel.G -or $pixel.G -ne $pixel.B)) { Add-Error "Image is not mathematically grayscale: $Path"; return }
                }
            }
            if ($AlphaContract -eq 'opaque' -and $sawTransparent) { Add-Error "Image must be opaque: $Path" }
            if ($AlphaContract -eq 'transparent' -and -not $sawTransparent) { Add-Error "Image must contain transparency: $Path" }
        }
    } finally { $bitmap.Dispose() }
}

$PackageRoot = (Resolve-Path -LiteralPath $PackageRoot).Path
$manifestPath = Join-Path $PackageRoot 'asset-manifest.json'
$manifest = Read-Json $manifestPath
if ($null -ne $manifest) {
    if ($manifest.schema_version -ne '4.1.0' -or $manifest.package_name -ne 'AssetRounds Production Brand Handoff V4.1' -or $manifest.created_date -ne '2026-08-15') { Add-Error 'Manifest V4.1 identity is incorrect.' }
    if ($manifest.scores.handoff_status -ne 'S10_ACTIVATION_PACKET_READY' -or $manifest.scores.release_status -ne 'RELEASE_GATES_OPEN' -or $manifest.scores.release_ready) { Add-Error 'Manifest readiness wording is incorrect.' }
    if (@($manifest.s10_contracts.lifecycle) -join '|' -ne 'Package|Inventory|ComponentSystem|Migration|AutomatedLab|PhysicalExperience|Release') { Add-Error 'Manifest lifecycle is incorrect.' }
    $actual = @{}
    Get-ChildItem -LiteralPath $PackageRoot -Recurse -File | Where-Object { $_.FullName -ne $manifestPath } | ForEach-Object {
        $relative = $_.FullName.Substring($PackageRoot.Length + 1).Replace('\','/')
        $actual[$relative] = $_
    }
    $declared = @{}
    foreach ($entry in @($manifest.files)) {
        if ($declared.ContainsKey([string]$entry.path)) { Add-Error "Duplicate manifest path: $($entry.path)"; continue }
        $declared[[string]$entry.path] = $entry
        if (-not $actual.ContainsKey([string]$entry.path)) { Add-Error "Manifest file missing: $($entry.path)"; continue }
        $file = $actual[[string]$entry.path]
        if ($file.Length -ne [long]$entry.byte_length) { Add-Error "Manifest byte length mismatch: $($entry.path)" }
        $sha = (Get-FileHash -Algorithm SHA256 -LiteralPath $file.FullName).Hash
        if ($sha -ne [string]$entry.sha256) { Add-Error "Manifest SHA-256 mismatch: $($entry.path)" }
    }
    foreach ($path in $actual.Keys) { if (-not $declared.ContainsKey($path)) { Add-Error "Unmanifested file: $path" } }
}

$required = @(
    'README.md','LICENSE_AND_PROVENANCE.md','VERSION_HISTORY.md','AppIcon/README.md','Handoff/INSTALLATION_MAP.md',
    'Handoff/S10_ACTIVATION_PACKET.md','Handoff/S10_VISUAL_REFRESH_RUNBOOK.md','Handoff/S10_STAGE_CHECKPOINTS.md',
    'Handoff/S10_TOKEN_COVERAGE.md','Handoff/S10_ACCESSIBILITY_AND_FIELD_PROTOCOL.md','Handoff/S10_VISUAL_REGRESSION_CONTRACT.md',
    'Handoff/S10_EXPERIENCE_VALIDATION.md','Handoff/S10_STORE_AND_COMPLIANCE.md','Handoff/S10_EVIDENCE_LOCK.md',
    'Tools/validate-json-strict.py','Tools/validate-json-schema-subset.py','Tools/validate-s10-contracts.ps1'
)
foreach ($relative in $required) { if (-not (Test-Path -LiteralPath (Join-Path $PackageRoot $relative) -PathType Leaf)) { Add-Error "Required file missing: $relative" } }

$jsonFiles = @(Get-ChildItem -LiteralPath $PackageRoot -Recurse -File -Filter '*.json')
$strictOutput = & python (Join-Path $PSScriptRoot 'validate-json-strict.py') @($jsonFiles.FullName) 2>&1
if ($LASTEXITCODE -ne 0) { Add-Error "Strict JSON validator failed: $($strictOutput -join '; ')" }
$contractOutput = & pwsh.exe -NoProfile -File (Join-Path $PSScriptRoot 'validate-s10-contracts.ps1') -Mode Package 2>&1
if ($LASTEXITCODE -ne 0) { Add-Error "S10 Package validator failed: $($contractOutput -join '; ')" }

$score = Read-Json (Join-Path $PackageRoot 'Scorecard/v1-v2-v3-v4-score.json')
if ($null -ne $score) {
    $sum = (@($score.categories) | Measure-Object -Property v4_1 -Sum).Sum
    $weight = (@($score.categories) | Measure-Object -Property weight -Sum).Sum
    if ($sum -ne 92 -or $weight -ne 100 -or $score.v4_1_total -ne 92) { Add-Error 'V4.1 score arithmetic is incorrect.' }
    if ($score.handoff_status -ne 'S10_ACTIVATION_PACKET_READY' -or $score.release_status -ne 'RELEASE_GATES_OPEN' -or $score.release_ready) { Add-Error 'Score readiness wording is incorrect.' }
}

$imageContracts = @{}
if ($null -ne $manifest) { foreach ($contract in @($manifest.image_contracts)) { $imageContracts[[string]$contract.path] = $contract } }
foreach ($relative in $imageContracts.Keys) {
    $contract = $imageContracts[$relative]
    Test-Image (Join-Path $PackageRoot $relative) ([int]$contract.width) ([int]$contract.height) 'any'
}
Test-Image (Join-Path $PackageRoot 'AppIcon/AppIcon-Default-1024.png') 1024 1024 'opaque' $false
Test-Image (Join-Path $PackageRoot 'AppIcon/AppIcon-Dark-1024.png') 1024 1024 'transparent' $false
Test-Image (Join-Path $PackageRoot 'AppIcon/AppIcon-Tinted-1024.png') 1024 1024 'opaque' $true

$appIcon = Read-Json (Join-Path $PackageRoot 'AppIcon/Contents.json')
if ($null -ne $appIcon) {
    $names = @($appIcon.images.filename | Sort-Object)
    if (($names -join '|') -ne 'AppIcon-Dark-1024.png|AppIcon-Default-1024.png|AppIcon-Tinted-1024.png') { Add-Error 'AppIcon Contents.json references are incorrect.' }
}
$original = Read-Json (Join-Path $PackageRoot 'Brand/XcodeImagesets/AssetRoundsBrandSymbol.imageset/Contents.json')
$template = Read-Json (Join-Path $PackageRoot 'Brand/XcodeImagesets/AssetRoundsBrandSymbolTemplate.imageset/Contents.json')
if ($original.properties.'template-rendering-intent' -ne 'original' -or $template.properties.'template-rendering-intent' -ne 'template') { Add-Error 'Image-set rendering intents are incorrect.' }

$textExtensions = @('.md','.json','.ps1','.py')
foreach ($file in @(Get-ChildItem -LiteralPath $PackageRoot -Recurse -File | Where-Object { $textExtensions -contains $_.Extension.ToLowerInvariant() })) {
    $bytes = [System.IO.File]::ReadAllBytes($file.FullName)
    if ($bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF) { Add-Error "UTF-8 BOM is forbidden: $($file.FullName)" }
    for ($i=0; $i -lt $bytes.Length; $i++) { if ($bytes[$i] -eq 13) { Add-Error "CR/CRLF is forbidden: $($file.FullName)"; break } }
}

if ($errors.Count -gt 0) { foreach ($validationError in $errors) { Write-Error $validationError }; exit 1 }
Write-Output 'PASS: AssetRounds Brand Handoff V4.1 package.'
