# AssetRounds iOS app icon — Brand Handoff V4.1

| File | Contract |
| --- | --- |
| `AppIcon-Default-1024.png` | 1024×1024, opaque, square, unmasked |
| `AppIcon-Dark-1024.png` | 1024×1024, transparent background, approved color mark |
| `AppIcon-Tinted-1024.png` | 1024×1024, opaque true-grayscale source |
| `Contents.json` | Universal iOS Any, Dark, and Tinted mappings |

Destination: `FieldEvidenceApp/Resources/Assets.xcassets/AppIcon.appiconset/`.

The application target's primary app-icon setting must resolve to `AppIcon`. S10.2 must inspect `FieldEvidenceApp.xcodeproj/project.pbxproj` and the target's effective build settings. If required by repository truth, the authorized project change is `ASSETCATALOG_COMPILER_APPICON_NAME = AppIcon` in every applicable target build configuration. Do not change signing, bundle ID, deployment target, capability, target, or scheme.

The three PNGs plus `Contents.json` are four of 12 runtime asset files. `project.pbxproj` is the thirteenth integration path, not a runtime asset. Verification requires exact-head asset-catalog compilation and runtime/system-context inspection through the authorized macOS CI route.

Apple references: https://developer.apple.com/documentation/xcode/configuring-your-app-icon/ and https://developer.apple.com/design/human-interface-guidelines/app-icons/.
