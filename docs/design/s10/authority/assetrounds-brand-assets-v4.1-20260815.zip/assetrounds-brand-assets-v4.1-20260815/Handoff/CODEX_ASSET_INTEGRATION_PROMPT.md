# Copy-ready Codex asset-integration prompt — Brand Handoff V4.1

```text
Integrate AssetRounds Brand Handoff V4.1 only under a frozen repository task that names all 13 exact integration paths: the 12 runtime files in Handoff/INSTALLATION_MAP.md plus FieldEvidenceApp.xcodeproj/project.pbxproj. This package is not repository authority and is separate from Foundation & Build Plan V4.

Read repository authority and verify the activation ZIP digest, manifest digest, manifest enumeration, branch/head, allowed paths, workflow/toolchain, and S10.2 selector before mutation. Stop on any unresolved REQUIRED_* value or mismatch.

Copy only the 12 runtime files. Inspect project.pbxproj and effective target build settings; if necessary and authorized, set ASSETCATALOG_COMPILER_APPICON_NAME = AppIcon for every applicable configuration. Do not change signing, bundle ID, target, scheme, deployment target, capability, behavior, navigation, persistence, privacy use, or adjacent UI.

S10.2 proves the semantic tokens/shared components and asset integration in isolation. It does not claim feature-screen migration; those coverage rows stay NOT_RUN until S10.3. Use native SwiftUI controls/SF Symbols for ordinary actions, the original brand symbol only for restrained brand moments, and the template symbol only for semantic tinting. Hide decorative images from accessibility and label meaningful controls plainly.

Verify through the activation-pinned macOS workflow: effective AppIcon setting, asset compilation, install/launch, original/template rendering, supported appearances/contexts, accessibility semantics, exact-head artifacts, and checksums. Record E product and descendant K evidence separately. This task does not authorize screenshots/metadata/store actions, signing, upload, submission, or redesign.
```
