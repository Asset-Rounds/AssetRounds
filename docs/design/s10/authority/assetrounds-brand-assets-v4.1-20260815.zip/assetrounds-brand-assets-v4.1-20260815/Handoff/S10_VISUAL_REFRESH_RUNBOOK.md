# S10 — AssetRounds visual-system refresh (Brand Handoff V4.1)

Brand Handoff V4.1 is a reviewed activation contract, not repository authority and not the application's Foundation & Build Plan V4. Execute only a card selected by a frozen repository task whose plan/runbook hashes and per-card authority match `s10-activation.json`.

## Preconditions and invariants

S10 starts from an accepted S9 base product head and exact-main CI evidence. Activation must choose `post_release_update` for a published S9 release or `replace_unpublished_candidate` for an unpublished candidate and supply the corresponding evidence. The latter replaces earlier candidate/TestFlight/store evidence at S10.6; the former produces a separately versioned update. Do not invent publication state or evidence.

Preserve behavior, navigation, persistence/data meaning, privacy use, commerce, supported devices, reports, backup/restore, and the approved mark/palette. A design change cannot disguise a product change. Signing, beta/App Store operations, upload, and submission remain owner-only.

All target instances use canonical `docs/design/s10/s10-*.json` filenames. Every card has exact fully expanded paths, caps, branch, selector, and selector hash in activation. Unknown repository/legal/product facts remain activation inputs.

## Lifecycle and receipts

| Card | Validator mode | Independently accepted outcome |
| --- | --- | --- |
| S10.1 | `Inventory` | Frozen S9 graph, tasks, profiles, baselines, budgets, and store plan |
| S10.2 | `ComponentSystem` | Assets, primary AppIcon setting, semantic tokens/components pass in isolation; screens remain `NOT_RUN` |
| S10.3 | `Migration` | Every frozen feature-screen state is migrated and `PASS` |
| S10.4 | `AutomatedLab` | Automated appearance/accessibility/localization/visual proof passes; manual fields may remain open |
| S10.5 | `PhysicalExperience` | Owner-bridged physical install, manual accessibility, field/durability/performance proof passes |
| S10.6 | `Release` | Store/privacy/supply-chain/legal gates and historical evidence lock pass |

Each stage records E (accepted product head), descendant K (evidence head), and later C (receipt/bookkeeping commit). Product CI runs at E. Documents are hashed from `git show <blob_commit>:<path>`. C never records its own SHA. Earlier checkpoint rows remain immutable.

## S10.1 — Inventory

1. Hydrate and freeze activation, including ZIP and external manifest digests, route, repository/pins/toolchain/workflow, exact card authority, locale/device/pseudolanguage profiles, physical distribution bridge, and rights-attestation evidence.
2. Inventory every route/state, exact source path, deterministic fixture, unchanged S9 behavior, task, baseline, device profile, migration slice, component, and token plan.
3. Freeze accessibility common tasks across all profiles/features. Results remain unrun.
4. Freeze S9 visual baselines and all 14 requirement families.
5. Freeze the physical plan: at least five sessions/three roles/daylight/low light, eight durability families, five performance families, and measurement methods/budgets.
6. Freeze release-locale store slots/claims using a current Apple specification URL and checked date; keep pseudolanguages separate.
7. Append the `Inventory` E/K checkpoint and run `-Mode Inventory`.

Acceptance: complete graph and plans, no placeholders or target result promoted early.

## S10.2 — Component system and asset integration

1. Copy the exact 12 runtime files in `INSTALLATION_MAP.md`.
2. Inspect authorized `FieldEvidenceApp.xcodeproj/project.pbxproj` and effective build settings. Ensure each applicable application-target configuration resolves `ASSETCATALOG_COMPILER_APPICON_NAME = AppIcon`; change only this property if repository truth and card authority require it. The project file is integration path 13, not a runtime asset.
3. Implement only S10.1-proven reusable semantic tokens/components in activation-authorized source/test paths. Prefer native SwiftUI controls and SF Symbols.
4. Run isolated exact-E compilation/tests through the pinned macOS workflow and inspect runtime asset contexts.
5. Set token document to `components_implemented`: component rows `PASS`, feature-screen coverage rows still `NOT_RUN`, `component_system_product_head = E`.
6. Append `ComponentSystem` E/K with evidence IDs `appicon-primary-build-setting` and `runtime-asset-count-12`, then run `-Mode ComponentSystem`.

Acceptance: primary AppIcon/project integration and isolated components pass without claiming feature-screen adoption.

## S10.3 — Migration

1. Follow the frozen migration order and exact card paths; do not combine or skip states.
2. Replace ad hoc presentation with approved semantic tokens/components without changing behavior or accessibility meaning.
3. Run each authorized selector at exact product E and retain evidence at K.
4. Set every applicable screen coverage row to `PASS`, set `migration_product_head = E`, and require zero untracked visual constants.
5. Append `Migration` E/K and run `-Mode Migration`.

Acceptance: every frozen state is migrated; automated/manual candidate evaluation is still not claimed.

## S10.4 — Automated lab

1. Against migrated E, run automated accessibility for every task × feature × profile. Record PASS, justified NOT_APPLICABLE, or an exception with issue, owner, expiry, rationale, reviewer, and evidence.
2. Generate/hash candidate images and compare every frozen row for Light, Dark, Increased Contrast, AX text, minimum OS, Differentiate Without Color, Reduce Motion, Reduce Transparency, Double Length, RTL, RTL String, Tall, Accented, and Bounded.
3. Require visual `PASS` and human `APPROVED`; record intended changes explicitly.
4. Do not require or imply S10.5 physical sessions. Manual accessibility may remain `NOT_RUN` and experience remains planned.
5. Append `AutomatedLab` E/K and run `-Mode AutomatedLab`.

## S10.5 — Physical experience

1. The owner signs/distributes E through the frozen `testflight`, `owner_signed_development`, or `ad_hoc` bridge; Codex does not perform owner-only signing/upload absent separate authority.
2. Record installation evidence, installed product head E, build SHA-256, physical device/profile/OS, role, lighting, tasks, scenarios, reviewer, and result for every session.
3. Complete manual accessibility rows for all activated profiles.
4. Execute all applicable durability families and every frozen performance family/method. Conditional S9-absent behaviors may be `NOT_APPLICABLE` only with frozen rationale.
5. Require five passing sessions, three roles, both lighting conditions, all applicable results passing, and zero severe issues.
6. Append `PhysicalExperience` E/K and run `-Mode PhysicalExperience`.

## S10.6 — Release

1. Freeze final product E; any later product change invalidates candidate evidence until rerun.
2. Run the named full release workflow at E and lock the successful run/artifacts.
3. Reconcile PrivacyInfo, required-reason APIs, SDK manifests/signatures, archive privacy report, App Store privacy answers, platform compatibility, legal URLs, and owner age-rating answers.
4. Generate actual screenshots from E. For each device-class/release-locale group enforce slots 1–10 and the first-three story order, exact pixel/orientation/format/no-alpha, Apple specification URL/date, hashes, and truthful claim linkage.
5. Record accessibility-label eligibility and App Tags. App Tags may be `NOT_AVAILABLE` with evidence; never invent a tag. Record CPP/PPO only under owner authority.
6. Require accepted owner rights/use attestation plus separate trademark/name/claim/URL clearance evidence.
7. Create locked store readiness and evidence lock at descendant K; hash every historical blob at its recorded commit. Append `Release` E/K. Create later receipt C without self-recording.
8. Run `-Mode Release -RepositoryRoot <repo>`.

Acceptance: every applicable hard gate passes, successful CI head equals E, E is ancestor of K, historical hashes match, and no external store/signing action is inferred.

## Stop boundary

Completion hands the locked evidence to the owner. Publication, TestFlight/App Store Connect mutation, signing, upload, submission, and post-live experimentation need separate authority.
