# S10 accessibility and field protocol — Brand Handoff V4.1

The frozen common-task matrix covers every task across every activated device profile and all seven features: VoiceOver, Voice Control, Larger Text, Dark Interface, Differentiate Without Color, Sufficient Contrast, and Reduced Motion.

## S10.4 automated lab

For each task × feature × profile row, record automated status, evidence IDs, and reviewer. Accepted automated outcomes are `PASS`, justified `NOT_APPLICABLE`, or `EXCEPTION`. An exception is incomplete without a tracked issue, accountable owner, ISO date expiry, rationale, and evidence. S10.4 uses `automated_evaluated`; manual fields may remain `NOT_RUN` and no physical-device claim is implied.

Automated visual coverage must include Light, Dark, Increased Contrast, AX text, Differentiate Without Color, Reduce Motion, Reduce Transparency, minimum OS, and all six pseudolanguage families: Double Length, RTL, RTL String, Tall, Accented, and Bounded.

## S10.5 physical experience

The same rows add manual status, evidence, and reviewer. `evaluated` requires `PASS` or justified `NOT_APPLICABLE` for every manual row. VoiceOver and Voice Control common tasks require real interaction evidence; screenshots alone do not substitute.

Every physical session records distribution route, installation evidence, installed product head, build SHA-256, physical device/profile/OS, role, lighting, tasks, scenarios, result, and reviewer. The installed product head must equal the evaluated product E. Signing or TestFlight operation remains owner-only.
