# S10 visual-regression contract — Brand Handoff V4.1

S10.1 freezes historically hashed S9 baseline images for every required screen state and activated device profile. S10.2 and S10.3 preserve those baselines while components and screens change; intended changes use explicit change records.

S10.4 sets `automated_evaluated` only after candidate images from the migrated product head are independently hashed, compared, and human-reviewed. Every required row must be `PASS` and `APPROVED`.

The matrix contains exactly these required families: default Light, default Dark, Increased Contrast, AX text, Double Length, RTL, RTL String, Tall, Accented, Bounded, Differentiate Without Color, Reduce Motion, Reduce Transparency, and minimum OS. Locale/profile identifiers are frozen in activation. A release-locale screenshot cannot substitute for a pseudolanguage test, and pseudolanguage output cannot be used as store metadata.

Release preserves the evaluated document at its historical blob commit and requires its candidate product head to match final product E.
