# Brand and S10 validation matrix — Brand Handoff V4.1

| Gate family | First accepting stage | Required evidence |
| --- | --- | --- |
| Package hashes, JSON/schema, approved image bytes/contracts | Package | Manifest/template/image validators |
| Routes, states, fixtures, profiles, tasks, baseline and store plans | Inventory | Frozen canonical instances |
| 12 runtime files, primary AppIcon project setting, semantic components/tokens | ComponentSystem | Exact E build/tests and K evidence; screen rows still NOT_RUN |
| Every feature-screen state uses approved components/tokens | Migration | Full PASS coverage, zero untracked visual constants |
| Light/Dark/contrast/AX/minimum OS and six pseudolanguages | AutomatedLab | Automated accessibility plus PASS/APPROVED visual evidence |
| Manual accessibility, five sessions/three roles/light conditions | PhysicalExperience | Owner-bridged installed E and manual evidence |
| Eight durability and five performance families | PhysicalExperience | Frozen-method physical-device results |
| Privacy, dependencies/signatures/APIs, archive, age rating | Release | Locked current product/archive evidence |
| Screenshot locale/spec URL/date/order, truthful claims | Release | Actual E screenshots and claim map |
| App Tags/accessibility labels/CPP/PPO | Release | PASS or explicitly allowed NOT_AVAILABLE disposition |
| Rights and trademark/name/URL/claim clearance | Activation/Release | Accepted use attestation; separate clearance at Release |
| Final lock | Release | CI at E, descendant evidence K, historical blob hashes, later C receipt |

Every applicable hard gate must pass. `Package` PASS means only that V4.1 is internally valid. Signing, TestFlight/App Store operation, upload, and submission remain separately authorized owner actions.
