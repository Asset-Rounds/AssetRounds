# S10 stage checkpoints — Brand Handoff V4.1

`s10-stage-checkpoints.json` is an append-only receipt index with six independently valid rows, in order: `Inventory`, `ComponentSystem`, `Migration`, `AutomatedLab`, `PhysicalExperience`, `Release`.

Each row records product head E, evidence head K, `evidence_head_role: K`, historically addressable documents, and evidence IDs. For every document, `blob_commit` identifies the commit whose blob is hashed; validation reads `git show <blob_commit>:<path>` and hashes those exact bytes. E must be an ancestor of K. A later checkpoint may use a new E/K pair, but cannot rewrite earlier evidence.

The receipt model is `E_product_K_evidence_C_receipt`:

- E contains the accepted product change and is the head tested by product CI.
- K is a descendant containing only evidence/checkpoint material permitted by repository authority.
- C is the later bookkeeping commit containing the cumulative checkpoint update. C cannot record its own SHA and is recorded after creation in repository handoff history.

`tracking` is used through the first five rows; `release_locked` has all six. The Release row and evidence lock can hash the final cumulative checkpoint file at its historical blob commit without self-reference.
