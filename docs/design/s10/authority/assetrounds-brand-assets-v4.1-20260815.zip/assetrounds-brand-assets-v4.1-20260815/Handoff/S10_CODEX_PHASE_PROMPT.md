# Copy-ready future S10 prompt — Brand Handoff V4.1

Use only after the owner has frozen a schema-valid `docs/design/s10/s10-activation.json` and repository authority selects S10.1.

```text
Complete only the currently selected AssetRounds S10 card. Brand Handoff V4.1 is an activation contract, not authority and not Foundation & Build Plan V4.

At each card, read repository authority and validate the activation, exact card paths/caps/selector, pins, branch/base, workflow/toolchain, and preceding E/K/C evidence. Stop on placeholders or mismatches. Preserve S9 behavior, navigation, data meaning, persistence, privacy use, commerce, devices, and scope.

Execute in order with one independent validator mode each:
S10.1 Inventory — freeze routes/states/fixtures/profiles/tasks/baselines/plans.
S10.2 ComponentSystem — integrate 12 runtime assets plus authorized project.pbxproj AppIcon setting; prove components/tokens in isolation; do not mark screens migrated.
S10.3 Migration — migrate every frozen feature-screen state and make coverage PASS.
S10.4 AutomatedLab — run automated appearance/accessibility/localization/pseudolanguage/visual proof; do not claim manual/physical evidence.
S10.5 PhysicalExperience — use the owner-operated beta/device bridge and record installed E, manual accessibility, field, durability, and performance evidence.
S10.6 Release — revalidate privacy/dependencies/archive/age rating/screenshots/claims/store decisions/rights and clearance; run full CI at E; record descendant K historical evidence and later C receipt.

Use only canonical docs/design/s10/s10-*.json filenames. Product CI head equals E; evidence K descends from E; C never self-records. Signing, TestFlight/App Store operation, upload, and submission remain owner-only unless separate authority explicitly names them.
```
