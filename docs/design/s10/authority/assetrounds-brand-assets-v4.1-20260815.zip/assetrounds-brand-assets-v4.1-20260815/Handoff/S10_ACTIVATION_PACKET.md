# S10 activation packet — Brand Handoff V4.1

This package is a reviewed activation contract, not repository authority and not release approval. Before S10.1, the owner must create `docs/design/s10/s10-activation.json` from the supplied schema/template and replace every `REQUIRED_*` value with repository truth.

## Required authority

The frozen activation records the owner approval; repository/remote/main/base/S10 branches; authority document; SHA-256-pinned plan and runbook; workflow path/ref/hash; runner, Xcode, SDK, Swift, project, target, scheme, configuration, and minimum-iOS values; exact allowed remote operations; and per-card branch, fully expanded paths, caps, selector object, and selector hash.

The six cards and validator stages are one-to-one:

`S10.1 Inventory → S10.2 ComponentSystem → S10.3 Migration → S10.4 AutomatedLab → S10.5 PhysicalExperience → S10.6 Release`

## Package identity

Activation must pin both:

- SHA-256 of the final distributed ZIP bytes; and
- SHA-256 of `asset-manifest.json`.

Folder verification is canonical: enumerate every regular file below the package root except `asset-manifest.json`, normalize relative paths to forward slashes, sort ordinally, and require the exact manifest path set, byte length, and per-file SHA-256. The manifest is the folder trust anchor; its own digest is recorded outside itself in activation. ZIP SHA-256 is computed from the final ZIP bytes and cannot be inferred from a folder.

## Release route and S9 bridge

Choose exactly one truthful route:

- `post_release_update` with `publication_state: published` and published-release evidence; or
- `replace_unpublished_candidate` with `publication_state: unpublished` and unpublished-candidate evidence.

Both routes require the accepted S9 base product head and exact-main CI evidence. TestFlight evidence is required only when it exists for the chosen route; it is never silently fabricated. S10.5 additionally requires an owner-operated physical-device distribution bridge (`testflight`, owner-signed development, or ad hoc), an installation/build identity method, and evidence tying every installed build to product head E. Signing, upload, and submission remain owner-only.

## Rights and clearance

Activation requires a named rights holder and an owner-attested use grant covering the AssetRounds project, app, marketing, and distribution. The package does not assert that this grant has been accepted and does not provide trademark clearance. S10 execution remains closed until grant evidence is supplied; S10.6 release remains closed until separate trademark-clearance evidence is supplied.

## Canonical instance names

All hydrated instances live under `docs/design/s10/` and use the exact names `s10-activation.json`, `s10-stage-checkpoints.json`, `s10-screen-state-inventory.json`, `s10-accessibility-common-tasks.json`, `s10-token-coverage.json`, `s10-visual-regression.json`, `s10-experience-validation.json`, `s10-store-readiness.json`, and `s10-evidence-lock.json`.

Run `Tools/validate-s10-contracts.ps1 -Mode Package` on the package, then the mode matching the active card against hydrated repository instances with `-RepositoryRoot` and `-PackageZipPath`. Selector SHA-256 is computed over PowerShell's compact ordered JSON representation of the frozen selector object. A package PASS proves template integrity only.
