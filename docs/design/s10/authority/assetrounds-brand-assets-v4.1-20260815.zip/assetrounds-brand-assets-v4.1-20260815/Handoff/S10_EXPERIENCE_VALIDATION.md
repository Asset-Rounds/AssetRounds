# S10 physical experience validation — Brand Handoff V4.1

`s10-experience-validation.json` is planned at S10.1 and evaluated only at S10.5. S10.4 automated-lab evidence does not depend on this document being physically evaluated.

The plan requires at least five physical sessions across three roles, daylight and low light, all frozen common tasks, and six scenarios. Each installed build is bridged by owner-operated TestFlight, owner-signed development, or ad hoc distribution and is cryptographically tied to the evaluated product head E.

Durability covers eight families: offline save/reopen, reconnect/reopen, force-quit resume, camera-denial recovery, photo import if shipped, capture retake/delete/order, report export retry, and low storage if shipped. Conditional families may use `not_applicable_at_s9`/`NOT_APPLICABLE` only with frozen rationale.

Performance covers cold launch to usable, discrete-action feedback, capture to durable thumbnail, history retrieval, and report preview readiness. Each metric freezes method, condition, fixture, device profile, statistic, unit, S9 baseline, operator, and threshold before measurement.

`PhysicalExperience` requires all applicable durability/performance results and sessions to pass with zero severe issues. Release invalidates this evidence after any later product change until rerun.
