# AssetRounds Brand Handoff V4.1 installation map

This is a contract, not permission. Frozen activation and the active repository task must authorize every exact destination, `FieldEvidenceApp.xcodeproj/project.pbxproj`, selectors, branch, workflow, and evidence operation.

## Exact runtime files (12)

| Package source | Repository destination |
| --- | --- |
| `AppIcon/AppIcon-Default-1024.png` | `FieldEvidenceApp/Resources/Assets.xcassets/AppIcon.appiconset/AppIcon-Default-1024.png` |
| `AppIcon/AppIcon-Dark-1024.png` | `FieldEvidenceApp/Resources/Assets.xcassets/AppIcon.appiconset/AppIcon-Dark-1024.png` |
| `AppIcon/AppIcon-Tinted-1024.png` | `FieldEvidenceApp/Resources/Assets.xcassets/AppIcon.appiconset/AppIcon-Tinted-1024.png` |
| `AppIcon/Contents.json` | `FieldEvidenceApp/Resources/Assets.xcassets/AppIcon.appiconset/Contents.json` |
| Four files under `Brand/XcodeImagesets/AssetRoundsBrandSymbol.imageset/` | Same filenames under `FieldEvidenceApp/Resources/Assets.xcassets/AssetRoundsBrandSymbol.imageset/` |
| Four files under `Brand/XcodeImagesets/AssetRoundsBrandSymbolTemplate.imageset/` | Same filenames under `FieldEvidenceApp/Resources/Assets.xcassets/AssetRoundsBrandSymbolTemplate.imageset/` |

Do not copy symbol masters, research, source-reference images, schemas, templates, scorecards, evidence, manifest, or ZIP into the app.

## Project integration path (1)

Inspect `FieldEvidenceApp.xcodeproj/project.pbxproj`. The target's effective primary icon setting must be `ASSETCATALOG_COMPILER_APPICON_NAME = AppIcon` in every applicable configuration. Change this file only when frozen repository evidence shows the value is absent/wrong and the exact path is authorized. This produces 13 integration paths total but still only 12 runtime asset files.

## Preflight and verification

Verify final ZIP SHA-256, externally pinned manifest SHA-256, exact manifest enumeration/hashes, destination pre-install hashes, clean owned work, and exact authority. Validate dimensions, Default opacity, Dark transparency, Tinted grayscale, catalog references, and image-set rendering intent.

On the activation-pinned macOS workflow, prove effective build settings, asset-catalog compilation, install/launch, original/template rendering, and available Default/Dark/Tinted/generated-Clear/Home/Search/Settings/notification contexts. Record exact E, run, runner, Xcode/SDK/runtime, device, artifacts, screenshots, and checksums. CI compilation alone does not close appearance gates.

Rollback is a new task-owned corrective commit restoring only declared paths from recorded hashes. Never reset unrelated work or force-push. Signing, metadata, upload, and submission are outside this asset integration.
