# S10 evidence lock — Brand Handoff V4.1

S10.6 creates `s10-evidence-lock.json` only after product head E has passed the named full release workflow. The lock records E separately from descendant release-evidence head K. A later bookkeeping commit C contains the receipt but is never self-recorded.

The lock pins the activation ID, final ZIP SHA-256, asset-manifest SHA-256, S9 base product head, final product E, release-evidence K, canonical document IDs, machine-gate IDs, field/store evidence IDs, claims, and successful CI. Successful product CI `head_sha` must equal E—not K or C—and E must be an ancestor of K.

Every locked document has `path`, `blob_commit`, and SHA-256. Validation hashes the historical Git blob at that commit, not the mutable working-tree file. The lock excludes its own hash and cannot prove its own future C commit.

Release also requires the six ordered checkpoint rows, physical evidence tied to E, store evidence tied to E, accepted owner use-grant evidence, and separate trademark-clearance evidence. Package mode accepts only the intentionally incomplete template and makes no release claim.
