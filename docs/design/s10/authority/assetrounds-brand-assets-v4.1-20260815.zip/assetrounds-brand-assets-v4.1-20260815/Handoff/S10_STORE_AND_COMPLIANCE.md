# S10 store and compliance contract — Brand Handoff V4.1

`s10-store-readiness.json` is planned during S10.1 and locked during S10.6. It records evidence; it does not authorize signing, upload, App Store Connect mutation, TestFlight distribution, or submission.

Every screenshot slot and result records order 1–10, story role, device class/profile, release locale profile, orientation, exact pixels, current Apple-hosted specification URL, and the date that specification was checked. Results additionally record product head E, build identity, format, alpha status, path/hash, linked claims, evidence, and reviewer. For each device-class/locale group, the first three story roles are `find_asset`, `capture_evidence`, and `share_report` in that order.

App Tags accept `PASS` when a truthful current-market choice is selected or `NOT_AVAILABLE` when the feature/market is unavailable, with reviewer and evidence. Absence is not failure and must not be represented by an invented tag.

Release also locks current toolchain, privacy answers/manifests, dependency/signature and required-reason API inventory, archive privacy report, platform compatibility, legal URLs, age-rating owner answers, accessibility-label eligibility, Custom Product Page and Product Page Optimization dispositions, and truthful claims. Every applicable hard gate must pass.
