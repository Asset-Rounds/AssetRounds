# App Store creative and discovery plan — Brand Handoff V4.1

This plan does not authorize App Store Connect changes. S10.6 uses actual final product E and currently checked Apple specifications.

## Screenshot story

For every required device-class and release-locale group, plan 1–10 ordered slots. The first three are:

1. `find_asset` — locate or identify the inspected asset.
2. `capture_evidence` — show truthful evidence capture/review.
3. `share_report` — show the actual shipped report/share state.

Every slot and result records locale profile, device class/profile, orientation, exact pixels, the applicable Apple-hosted specification URL, and `apple_specification_checked_date`. Results also record source product E/build, PNG or JPEG, no alpha, path/hash, linked claim IDs, reviewer, and evidence. Never reuse pseudolanguage output as store creative.

Claims must map to shipped screen states and actual screenshots. Do not promise synchronization, teams, automation, AI, cloud behavior, or other unshipped capability.

## Discovery surfaces

Review App Tags per current market. Record a truthful selected value as `PASS`, or `NOT_AVAILABLE` with evidence if the surface/market is unavailable. Do not fabricate a value. Accessibility label eligibility derives from the completed common-task matrix. Custom Product Pages and Product Page Optimization require explicit owner authorization; otherwise record an evidenced `NOT_AVAILABLE`/deferred disposition without creating anything.

Privacy answers, legal URLs, age rating, SDK/dependency evidence, archive privacy report, and trademark/name/claim clearance remain hard release gates.
