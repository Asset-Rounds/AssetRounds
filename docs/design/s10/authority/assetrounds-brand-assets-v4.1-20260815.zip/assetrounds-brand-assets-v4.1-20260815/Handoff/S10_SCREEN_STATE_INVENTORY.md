# S10 screen/state inventory contract — Brand Handoff V4.1

S10.1 creates `docs/design/s10/s10-screen-state-inventory.json` and freezes every reachable screen, navigation destination, sheet, popover, menu, alert, confirmation, and empty/loading/unavailable/permission/error/offline/draft/saved/completed/lapsed/destructive state.

Each row names exact source files, S10.3 migration slice, deterministic fixture/starting condition, action/reach class, components/tokens, persistence wording, evidence relationships, accessibility semantics, common-task IDs, baseline IDs, and unchanged S9 behavior. Device profiles separately cover current and minimum supported environments.

Inventory fails on placeholders, globs, duplicates, missing fixtures/tasks/baselines/profiles, or unaccounted released states. The package template is intentionally empty. `Inventory` requires a complete frozen graph, planned token coverage, and frozen baselines. All later modes preserve its identity; they add product/evidence rather than rewrite S9 truth.
