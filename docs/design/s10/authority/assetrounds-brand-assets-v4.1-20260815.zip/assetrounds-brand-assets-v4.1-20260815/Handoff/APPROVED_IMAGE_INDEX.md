# Approved Brand Handoff V4.1 image index

Only the files below are approved. Rejected experiments are intentionally absent.

| File | Technical role | Destination/use | Do not do |
| --- | --- | --- | --- |
| `AppIcon/AppIcon-Default-1024.png` | Opaque 1024-pixel Any source | `AppIcon.appiconset` | Do not mask, round, add text, or add a vertical badge |
| `AppIcon/AppIcon-Dark-1024.png` | Transparent 1024-pixel Dark foreground | `AppIcon.appiconset`; system supplies background | Do not flatten a background behind it or add an outline |
| `AppIcon/AppIcon-Tinted-1024.png` | Opaque true-grayscale Tinted source | `AppIcon.appiconset`; system applies treatment | Do not manually recolor it as a final user tint |
| `Brand/AssetRounds-Symbol-Color-1024.png` | Transparent full-color master | External brand/layout master | For runtime use, prefer the prepared image set |
| `Brand/AssetRounds-Symbol-OneColor-1024.png` | Transparent deep-teal master | One-ink external use | For SwiftUI tinting, prefer the template image set |
| `Brand/AssetRounds-Symbol-Reversed-1024.png` | Transparent white master | Dark photography/documents after contrast check | Do not place on a light or uncontrolled background |
| `Brand/XcodeImagesets/AssetRoundsBrandSymbol.imageset/` | Original rendering at 1×/2×/3× | App asset catalog | Do not tint or rename files independently |
| `Brand/XcodeImagesets/AssetRoundsBrandSymbolTemplate.imageset/` | Template rendering at 1×/2×/3× | App asset catalog | Do not use without an approved semantic foreground style |
| `SourceReference/assetrounds-field-inspections-selected-concept.png` | Owner-selection board | Handoff/reference only | Never ship or submit as a screenshot |
| `SourceReference/approved-icons-small-size-qa.png` | Appearance/32-pixel review sheet; bytes retained from approved V2 | QA evidence only | Never bundle as an app asset |

## Master-brand rule

The symbol always means AssetRounds. Vertical discovery belongs in truthful App Store metadata, Custom Product Pages, screenshots, website landing pages, and in-app module nouns—not inside the permanent icon.

## Accessibility rule

- Decorative symbol next to visible brand text: hide the image from accessibility.
- Meaningful symbol used as a control: label the control or destination in plain language.
- Never expose asset filenames or the orbit/waypoint metaphor to VoiceOver.
