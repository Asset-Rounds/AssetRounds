# Brand Handoff V4 research-to-decision log

> This V4 is the brand/visual handoff generation, not the application's Foundation & Build Plan V4.

| Evidence | Decision | What V4 does not claim |
| --- | --- | --- |
| V3 already has approved imagery, tokens, inventory/accessibility/regression schemas, and cross-artifact validation | Preserve every approved runtime image/color byte-for-byte; improve execution evidence | A new icon or palette would improve field outcomes |
| Current field-app reviews emphasize speed, evidence durability, retrieval/reporting, and transparent commerce more than ornament | Add frozen task/performance budgets, durability scenarios, and truthful saved/commerce/store states | Review counts prove market-wide preference or authorize product repair |
| S10.4 previously combined automated matrices with five physical sessions and performance | Split lab evaluation (S10.4) from physical field/experience proof (S10.5) | More cards automatically create quality |
| Apple upload, privacy-manifest, SDK, screenshot, age-rating, and current-platform requirements are release-sensitive | Add exact toolchain, privacy/SDK, age-rating, store-readiness, and lock contracts in S10.6 | Brand S10 may change data use, SDKs, or app behavior |
| App Tags/CPP/PPO can improve discovery but require shipped truth and/or measured traffic | Plan and lock truthful decisions; keep publication/experiments owner-authorized and results post-live | A plan or suggested tag earns conversion evidence |
| Existing 91 score was capped mainly by unrun target proof; V4 adds one materially complete machine-checkable store/discovery contract | Raise only App Store readiness from 8→9, producing **92/100** | Templates earn physical-device, accessibility, legal, or release points |

## Card-count decision

Use six coding cards. S10.4 and S10.5 have different environments, evidence types, failure owners, and stop conditions, so combining them is operationally unsafe. A seventh coding card for post-release discovery would add ceremony to owner-operated App Store work; keep it as a measured owner follow-up after S10.6.

## Score ceiling

The package-only ceiling is **92/100** under the unchanged 100-point model. The 93–100 band requires target-environment and final-build proof, so increasing the package further would inflate prose/templates into evidence. The integrated score is recalculated after S10 and must still satisfy every hard gate.
