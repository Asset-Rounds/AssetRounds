# Apple requirements snapshot — 2026-08-14

Revalidate this file at the release task because Apple tooling and App Store specifications change.

## App-icon source contract

Apple's current asset-catalog guidance supports Any, Dark, and Tinted iOS appearances:

- A single 1024 × 1024 source can generate system variations.
- A supplied Tinted source must be grayscale.
- A supplied Dark source should use a transparent background so the system background can show through.
- iOS applies the final mask; source artwork remains square.
- The primary app-icon set is selected in target build settings.

Apple's current Human Interface Guidelines also describe Default, Dark, Clear Light, Clear Dark, Tinted Light, and Tinted Dark system appearances. Core visual features should remain consistent. The system can generate variants that are not explicitly supplied.

V3 retains the corrected Any/Dark/Tinted sources and requires actual supported-OS inspection of generated Clear/tint results. A future authorized Icon Composer task may add reviewed layered variants, but it must replace—not compete with—the asset-catalog source and prove visual parity.

Sources:

- https://developer.apple.com/documentation/xcode/configuring-your-app-icon/
- https://developer.apple.com/design/human-interface-guidelines/app-icons/
- https://developer.apple.com/documentation/xcode/creating-your-app-icon-using-icon-composer

## Accessibility and color

Apple recommends sufficient contrast, system colors where appropriate, light/dark/Increase Contrast testing, and communication beyond color alone. Apple cites WCAG Level AA guidance of 4.5:1 for normal-size text and 3:1 for larger/bold text.

V3 records exact brand-token contrast pairs and common-task protocols, but this is not a claim of complete accessibility. The rendered app still needs Accessibility Inspector, VoiceOver, Voice Control, Larger Text, Increase Contrast, Reduce Motion/Transparency, and real-device checks.

Sources:

- https://developer.apple.com/design/human-interface-guidelines/accessibility/
- https://developer.apple.com/design/human-interface-guidelines/color/
- https://developer.apple.com/design/human-interface-guidelines/voiceover/
- https://developer.apple.com/documentation/accessibility/performing-accessibility-audits-for-your-app
- https://developer.apple.com/help/app-store-connect/manage-app-accessibility/overview-of-accessibility-nutrition-labels/

## App Store screenshots and product pages

- App Store Connect accepts one to ten screenshots per supported device family/locale.
- Screenshot images cannot include transparency.
- Current accepted device dimensions must be rechecked at submission time.
- Custom Product Pages can present different truthful feature/vertical stories while preserving the same app identity.

Sources:

- https://developer.apple.com/help/app-store-connect/manage-app-information/upload-app-previews-and-screenshots
- https://developer.apple.com/help/app-store-connect/reference/app-information/screenshot-specifications/
- https://developer.apple.com/app-store/custom-product-pages/
