# Apple platform and App Store research — Brand Handoff V4

Collected 2026-08-14. Revalidate at S10 activation and release because runner images, SDK requirements, metadata rules, and App Store Connect surfaces change.

## Toolchain and platform

- Apple requires uploads made on or after 2026-04-28 to use Xcode 26 or later and the iOS/iPadOS 26 SDK or later. This is a submission minimum, not proof that the UI is correct.
- GitHub's macOS labels and installed Xcode versions can move. Brand S10 therefore pins and records runner image, explicit Xcode selection/version/build, SDK/runtime, device identity, workflow/ref, and exact `head_sha`.
- Standard SwiftUI controls adopt the current platform appearance. S10 compares iOS 26 with the minimum-supported iOS path and does not recreate Liquid Glass. `UIDesignRequiresCompatibility` is treated as a temporary escape, not a permanent design system.
- Icon Composer is optional. The approved asset-catalog icon remains valid and is the single source of truth; a layered Icon Composer migration would replace it and needs separate owner approval/parity proof.

Sources:

- https://developer.apple.com/news/upcoming-requirements/
- https://developer.apple.com/documentation/technologyoverviews/adopting-liquid-glass
- https://developer.apple.com/documentation/xcode/creating-your-app-icon-using-icon-composer
- https://docs.github.com/en/actions/reference/runners/github-hosted-runners
- https://github.com/actions/runner-images

## Accessibility and localization

- Accessibility Nutrition Labels are visible on supported OS versions. A feature is eligible only when every common task works on the applicable device type; automated audits alone are insufficient.
- Accessibility statements may affect search relevance, which makes truthful evidence both a usability and discovery opportunity. It is not permission to publish a partially tested feature.
- Localization context should include screenshots with exported localization content where supported. Retained `.xcresult` screenshots make regressions reviewable.

Sources:

- https://developer.apple.com/help/app-store-connect/manage-app-accessibility/overview-of-accessibility-nutrition-labels/
- https://developer.apple.com/documentation/accessibility/performing-accessibility-audits-for-your-app
- https://developer.apple.com/documentation/xcode/exporting-localizations
- https://developer.apple.com/documentation/xctest/adding-attachments-to-tests-activities-and-issues

## App Store screenshots and discovery

- Apple accepts one to ten screenshots. Current required size families must be checked at release, files must be JPEG/PNG without alpha, and screenshots must show the actual app in use.
- U.S. App Tags are generated from metadata and curation and can appear in search/product-page contexts. The developer should retain only truthful shipped-feature tags.
- Custom Product Pages support up to 70 localized variants with unique screenshots/promotional text/keywords and optional deep links on supported OS versions. AssetRounds should create a vertical page only after that vertical ships.
- Product Page Optimization can test store creative, but not a Custom Product Page. Apple exposes insight after at least five first-time downloads, uses 90% confidence for better/worse classifications, and permits tests up to 90 days. One-variable preregistration prevents storytelling after the result.

Sources:

- https://developer.apple.com/help/app-store-connect/reference/app-information/screenshot-specifications/
- https://developer.apple.com/help/app-store-connect/manage-app-information/upload-app-previews-and-screenshots
- https://developer.apple.com/help/app-store-connect/manage-app-information/manage-app-tags/
- https://developer.apple.com/help/app-store-connect/create-custom-product-pages/configure-multiple-product-page-versions
- https://developer.apple.com/help/app-store-connect/create-product-page-optimization-tests/run-a-test/

## Privacy, dependencies, and age rating

- An app using a required-reason API must declare an approved truthful reason in `PrivacyInfo.xcprivacy`; an invalid or incomplete manifest can block submission.
- Applicable third-party binary SDKs require valid privacy manifests and signatures. S10 records dependency evidence but cannot add/remove an SDK or change data use without separate product authority.
- The archive privacy report must reconcile with the manifest and App Store privacy answers.
- App Store age-rating answers must be current, including current social-media-capability questions even when the truthful answer is no.

Sources:

- https://developer.apple.com/documentation/bundleresources/describing-use-of-required-reason-api
- https://developer.apple.com/documentation/bundleresources/adding-a-privacy-manifest-to-your-app-or-third-party-sdk
- https://developer.apple.com/support/third-party-SDK-requirements/
- https://developer.apple.com/help/app-store-connect/manage-app-information/set-an-app-age-rating

## Performance evidence

- XCTest can measure launch, clock time, hitches, memory, CPU, storage, and signposted intervals.
- Apple describes roughly 100 ms as the upper bound for discrete interaction responsiveness. Brand S10 applies that only to immediate feedback, not photo processing, persistence, PDF generation, or network-independent long operations.
- Physical-device measurements own release decisions. Hosted-runner timing is diagnostic because shared CI hardware is not a stable field benchmark.

Sources:

- https://developer.apple.com/documentation/xctest/performance-tests
- https://developer.apple.com/documentation/xcode/improving-app-responsiveness
- https://developer.apple.com/documentation/swiftui/performance-analysis
- https://developer.apple.com/documentation/appstoreconnectapi/metriccategory
