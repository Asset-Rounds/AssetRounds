# V3 research-to-decision log

Collected: **2026-08-14**.

| Evidence | Decision | What V3 does not claim |
| --- | --- | --- |
| Field-app reviews value quick adoption, attached photos, durable state, and readable reports | S10 tests one-action hierarchy, one-handed capture, save confidence, evidence continuity, and report comprehension | Reviews do not prove a universal preference or that visual style alone causes ratings |
| Apple current-platform guidance says standard controls adopt the current appearance | Use native SwiftUI controls; review in current Xcode/OS; prohibit custom decorative Liquid Glass | No claim that the unbuilt app is already current-platform perfect |
| Apple supports automated accessibility audits | Run audits for every frozen state and preserve `.xcresult` evidence | Automated audits do not prove VoiceOver/Voice Control usability |
| Apple Accessibility Nutrition Labels require all common tasks to support a declared feature | Freeze a common-task matrix; publish only fully passing features | No accessibility label is preapproved in this package |
| Apple says accessibility features can influence search relevance | Treat truthful accessibility support as a discovery surface | No ranking or download increase is promised |
| Apple documents screenshot attachments but no built-in golden-image assertion | Freeze a repository-owned comparator, context, tolerance, hashes, and human review | A pixel threshold cannot override functional/accessibility review |
| Apple localization guidance supports pseudolanguage testing | Add Double-Length/RTL/Tall/Accented/Bounded coverage | No localization is claimed until real strings/layouts are tested |

The competitor-review, field-worker scoring, and Apple-platform audits were performed as independent research streams and reconciled into the V3 score and S10 contracts. URLs and limits are retained in the research files.

