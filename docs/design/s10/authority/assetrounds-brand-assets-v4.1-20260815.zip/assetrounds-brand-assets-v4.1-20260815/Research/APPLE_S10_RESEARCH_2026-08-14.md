# Apple S10 research snapshot — 2026-08-14

Revalidate these sources when S10 activates because Apple tooling, HIG guidance, and App Store Connect rules change.

## Current visual system

- Standard SwiftUI/UIKit components adopt the current system appearance on current OS releases. Apple advises reviewing an existing app in the latest Xcode rather than rebuilding custom materials.
- V3 therefore allows native current-platform presentation while prohibiting custom decorative Liquid Glass. The minimum-iOS-18 path must remain correct.
- Custom colors need Light, Dark, and Increased Contrast behavior. Reduce Transparency requires opaque alternatives to nonessential materials.

Sources:

- https://developer.apple.com/documentation/technologyoverviews/adopting-liquid-glass
- https://developer.apple.com/design/human-interface-guidelines/color
- https://developer.apple.com/documentation/swiftui/environmentvalues/accessibilityreducetransparency

## Icons

- Apple currently supports Icon Composer and asset-catalog sources. V3 retains the validated asset catalog as the single source of truth; it does not mix both routes.
- Current HIG describes default, dark, clear, and tinted appearances and emphasizes consistent core features.
- Icon Composer is a future option only after an authorized target-environment task proves visual parity. It is not required merely to raise the handoff score.

Sources:

- https://developer.apple.com/documentation/xcode/configuring-your-app-icon/
- https://developer.apple.com/documentation/xcode/creating-your-app-icon-using-icon-composer
- https://developer.apple.com/design/human-interface-guidelines/app-icons/

## Accessibility proof

- Accessibility Inspector and `XCUIApplication.performAccessibilityAudit` can find issues such as missing descriptions, small hit regions, contrast, clipping, and inaccessible content.
- Passing automated audits does not prove full accessibility; Apple still calls for real assistive-technology testing.
- Larger Text, VoiceOver, Voice Control, Dark Interface, Differentiate Without Color, Sufficient Contrast, and Reduced Motion need common-task evaluation before an App Store Accessibility Nutrition Label is published.
- Larger Text support means common tasks remain usable at 200% or more.

Sources:

- https://developer.apple.com/documentation/accessibility/performing-accessibility-audits-for-your-app
- https://developer.apple.com/help/app-store-connect/manage-app-accessibility/overview-of-accessibility-nutrition-labels/
- https://developer.apple.com/help/app-store-connect/manage-app-accessibility/voiceover-evaluation-criteria/
- https://developer.apple.com/help/app-store-connect/manage-app-accessibility/larger-text-evaluation-criteria
- https://developer.apple.com/help/app-store-connect/manage-app-accessibility/reduced-motion-evaluation-criteria

## Discovery implication

Apple states that Accessibility Nutrition Label features can participate in App Store search relevance. V3 treats this as an additional truthful discovery surface, not as permission to publish untested labels or add hidden keyword claims.

## Localization and screenshots

- Use String Catalogs/localization-aware APIs and test pseudolanguages, including Double-Length and RTL variants.
- App Store product pages accept one to ten screenshots in current accepted dimensions; screenshots cannot have alpha.
- XCUITest can retain screenshot attachments in `.xcresult`, but Apple documents no built-in golden-image comparison assertion. S10 must own its comparator and freeze device, OS, locale, appearance, content size, fixture, motion, and baseline hash.
- Custom Product Pages can use truthful unique screenshots, keywords, and optional deep links after the represented feature ships and the page passes review.

Sources:

- https://developer.apple.com/documentation/xcode/localizing-and-varying-text-with-a-string-catalog
- https://developer.apple.com/documentation/xcode/preparing-your-interface-for-localization
- https://developer.apple.com/documentation/xctest/adding-attachments-to-tests-activities-and-issues
- https://developer.apple.com/help/app-store-connect/reference/app-information/screenshot-specifications/
- https://developer.apple.com/help/app-store-connect/create-custom-product-pages/configure-multiple-product-page-versions

