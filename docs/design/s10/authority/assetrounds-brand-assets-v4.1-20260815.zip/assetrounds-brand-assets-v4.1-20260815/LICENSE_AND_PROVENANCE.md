# Asset provenance, rights input, and use boundary — Brand Handoff V4.1

The AssetRounds mark began as an owner-selected AI-generated internal concept and was mechanically refined into the included raster assets. The recorded chain is owner selection, OpenAI ImageGen through Codex Desktop (exact internal image-model identifier unavailable), retained generation IDs in `asset-manifest.json`, resize/flatten/alpha/grayscale processing, and byte-identical preservation through V4.1. No copied competitor artwork, stock icon, or third-party texture is represented as included.

The historical prompt text is incomplete. This is disclosed provenance, not a warranty. Apple system typography and SF Symbols are recommended but not redistributed and remain subject to Apple's terms.

## Required owner attestation

This document does **not** itself grant rights and does not state that the package owner is the rights holder. Before S10 execution, a named rights holder must accept and evidence a nonexclusive use grant whose explicit scope covers use, reproduction, adaptation/resize/format conversion, integration, display, and distribution of these assets for the AssetRounds project, app binaries, product pages, and marketing. The acceptance identifier is recorded in frozen `s10-activation.json`.

Do not invent the rights holder, acceptance, scope, or evidence. If the named holder cannot give that attestation, activation fails closed.

## Separate trademark gate

The use attestation does not establish name availability, trademark clearance, exclusivity, non-infringement, or rights in third-party marks. Commercial release requires separate dated trademark/name-clearance evidence and owner/legal approval. V4.1 intentionally leaves `trademark_clearance_status` as `NOT_CLEARED` in the template.

This is provenance and an evidence contract, not legal advice or a guarantee.
