# Brand Handoff V4.1 source-reference evidence

`assetrounds-field-inspections-selected-concept.png` records the owner's selected broad brand direction and lockup relationship. It is not an App Store screenshot, launch screen, in-app texture, or production asset-catalog image.

`approved-icons-small-size-qa.png` shows the approved Default, transparent Dark composited on the intended dark canvas, and true-grayscale Tinted sources at presentation and 32-pixel sizes. Brand Handoff V4.1 intentionally retains the accepted V2 image bytes. It is visual QA evidence, not a runtime asset.

Use the production files under `AppIcon/` and `Brand/XcodeImagesets/` for integration.
