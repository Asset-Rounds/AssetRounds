# AssetRounds production Brand Handoff V4.1

> Brand Handoff V4.1 is separate from the application's Foundation & Build Plan V4.

Approved identity: **AssetRounds — Field Inspections**. Current launch positioning: **AssetRounds: Sign Inspection**.

V4.1 preserves all 14 approved PNG bytes and the approved colors. It repairs the S10 authority, lifecycle, evidence, accessibility, physical-install, store, and rights contracts without claiming target results.

## Readiness

- Package score: **92/100**
- Handoff status: **S10_ACTIVATION_PACKET_READY**
- Release status: **RELEASE_GATES_OPEN**
- Release-ready: **No**

This means the package/templates validate and are ready for owner hydration. It does not mean S10 is authorized, implemented, compiled, tested, legally cleared, signed, uploaded, or submitted. Every `REQUIRED_*` activation value and every target gate remains owner/repository evidence.

## Start here

1. `Handoff/S10_ACTIVATION_PACKET.md` — exact inputs and route choice.
2. `Handoff/S10_VISUAL_REFRESH_RUNBOOK.md` — six independent cards/stages.
3. `Handoff/INSTALLATION_MAP.md` — 12 runtime asset files plus one project integration path.
4. `Handoff/S10_STAGE_CHECKPOINTS.md` and `Handoff/S10_EVIDENCE_LOCK.md` — E/K/C receipts and historical hashing.
5. The screen, token, accessibility, visual, experience, and store contract documents.
6. `Tools/README.md` — package and hydrated validation commands.

Lifecycle:

`Package → Inventory → ComponentSystem → Migration → AutomatedLab → PhysicalExperience → Release`

Run package validation with PowerShell 7 and Python 3:

```powershell
pwsh.exe -NoProfile -File .\Tools\validate-brand-handoff.ps1
```

Only the 12 files named as runtime assets in `Handoff/INSTALLATION_MAP.md` belong in the app asset catalog. Schemas, templates, research, scorecards, evidence, and ZIPs do not.
