# AssetRounds Brand Handoff scoring model V4.1

This 100-point model scores handoff quality, not application implementation or release approval. Evidence anchors are: 0% absent/invalid, 25% prose, 50% concrete artifact/specification, 75% reproducibly validated package contract, and 100% target proof when the category names a target environment. Templates and `NOT_RUN` never equal target evidence; no score waives a hard gate.

| Category | Weight |
| --- | ---: |
| App-icon system | 15 |
| Reusable symbol system | 8 |
| Tokens and usage rules | 11 |
| Brand architecture | 10 |
| Field usability and accessibility | 15 |
| Installation map | 10 |
| Codex integration prompt | 8 |
| Provenance and QA | 12 |
| App Store readiness | 11 |
| **Total** | **100** |

Bands: 0–59 incomplete; 60–74 design draft; 75–84 strong integration handoff; 85–92 activation-contract ready with named target gates; 93–100 release-candidate handoff material only with target evidence and all hard gates.

Hard gates include exact-project/Xcode compilation; supported appearance/device proof; automated and manual accessibility; physical field/durability/performance evidence; privacy/dependency/archive/age-rating reconciliation; accepted rights attestation; separate trademark/name/claim/URL clearance; truthful screenshots/store decisions; and final historical evidence lock.

Always report two states. V4.1 is `S10_ACTIVATION_PACKET_READY` and `RELEASE_GATES_OPEN`; `release_ready` is false. Owner hydration and repository authority are required before S10.1.
