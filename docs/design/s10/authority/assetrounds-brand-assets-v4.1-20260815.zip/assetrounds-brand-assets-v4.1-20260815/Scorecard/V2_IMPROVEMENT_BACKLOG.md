# V2 improvement backlog

> Historical V2 backlog retained for traceability. The active package backlog is `V4_IMPROVEMENT_BACKLOG.md`.

The approved mark and colors are frozen. Improve evidence and execution before reopening artwork.

The default execution vehicle is the six-card `Handoff/S10_VISUAL_REFRESH_RUNBOOK.md` after the completed S9 release baseline.

## P0 — integration correctness

- Install only through an authorized repository task.
- Validate all AppIcon/image-set references in the exact Xcode project.
- Require asset-catalog compilation and exact-head green CI.
- Capture Default, Dark, Tinted, and generated Clear appearances at system sizes.

## P1 — field and accessibility proof

- Run real-device outdoor daylight and night checks.
- Verify VoiceOver semantics for every brand-symbol use.
- Verify Increase Contrast, Dynamic Type, and Reduce Motion.
- Confirm branding never displaces the primary action or evidence content.

## P2 — release conversion assets

- After the UI is stable, produce the five truthful sign-inspection screenshots in `Handoff/APP_STORE_ASSET_PLAN.md`.
- Validate current screenshot dimensions and no-alpha rules.
- Run claims, name, trademark, and App Store Connect review.

## P3 — evidence from actual users

- Test icon recognition and product-page comprehension with at least five target field users.
- Test whether users understand `AssetRounds` as broader than signs without losing the specific sign promise.
- Record completion time, misunderstanding, trust, and screenshot preference; do not ask only whether the design is “liked.”

## Later, only if justified

- Commission a reviewed vector trace for print/large-format use.
- Explore Icon Composer/layered variants on a Mac while preserving geometry.
- Create Custom Product Pages only after each expansion is shipped.
