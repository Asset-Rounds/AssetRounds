# Brand Handoff V4.1 remaining target-evidence backlog

Reviewed Brand V4.1 closes the known package-contract gaps. Remaining points require owner hydration and target evidence, not more handoff prose or more cards.

1. S10.1 freezes actual S9 inventory, baselines, common tasks, store story, roles, durability scenarios, and physical-device performance budgets.
2. S10.2 compiles the exact asset catalog/design system with a pinned Xcode 26+ toolchain and proves current/minimum-iOS compatibility.
3. S10.3 migrates every frozen state without product/behavior drift.
4. S10.4 earns automated accessibility/localization/visual evidence and human approvals.
5. S10.5 earns physical-session/manual-assistive-tech/durability/performance evidence.
6. S10.6 locks privacy/SDK/age-rating/store creative/discovery and full exact-head release evidence.
7. Owner separately publishes/updates App Store metadata, Accessibility Nutrition Labels, App Tags, CPP/PPO, signs/uploads/submits, and measures post-live outcomes.

Do not add S10.7 merely to increase a score. Add a new card only if S9 repository inspection exposes a distinct product behavior, SDK/data-use change, unsupported device-family decision, or other owner-controlled implementation boundary.
