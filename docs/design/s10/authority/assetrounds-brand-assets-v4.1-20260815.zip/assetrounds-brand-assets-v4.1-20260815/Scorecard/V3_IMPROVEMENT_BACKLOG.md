# V3 remaining improvement backlog

V3 closes planning and handoff gaps. It intentionally leaves target proof to S10.

## S10 hard-gate work

1. Advance every V3 template through its named lifecycle stage from the exact released S9 app; never label planned or `NOT RUN` evidence as evaluated.
2. Compile assets/tokens/components in the exact Xcode project and retain exact-head CI evidence.
3. Capture supported icon/UI appearances and run per-screen automated accessibility audits.
4. Complete all common tasks with VoiceOver, Voice Control, Larger Text, Dark Interface, Differentiate Without Color, Sufficient Contrast, and Reduced Motion before publishing any matching label.
5. Run five real-device field sessions across at least three relevant user roles in daylight and low light.
6. Produce final screenshots and claim evidence from the accepted release candidate.
7. Complete owner/legal/name/rights and App Store Connect validation.

## Do not improve by redesigning

- Do not change the mark, palette, name, or expansion architecture merely to chase a score.
- Do not introduce custom glass, decorative textures, custom standard-action icons, or animated branding.
- Do not silently accept visual baselines or label unsupported accessibility features.
