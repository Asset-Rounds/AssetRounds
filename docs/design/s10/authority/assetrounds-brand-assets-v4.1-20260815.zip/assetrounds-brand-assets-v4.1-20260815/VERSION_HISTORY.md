# Version history

## Brand Handoff V4.1 — 2026-08-15

- Preserved all 14 approved PNG files byte-for-byte from V4.
- Changed readiness wording to `S10_ACTIVATION_PACKET_READY`; no implementation or release result is claimed.
- Made activation represent ZIP/manifest digests, repository/pin/workflow/toolchain authority, exact per-card paths/selectors, release route, rights input, and physical-device distribution bridge.
- Split validation into Inventory, ComponentSystem, Migration, AutomatedLab, PhysicalExperience, and Release.
- Added E product, K evidence, C receipt semantics and historical Git-blob hashing.
- Standardized hydrated filenames to `docs/design/s10/s10-*.json`.
- Separated automated/manual accessibility outcomes and added exception owner/expiry; completed pseudolanguage, durability, performance, screenshot specification/locale, and App Tags `NOT_AVAILABLE` contracts.
- Added `project.pbxproj`/`ASSETCATALOG_COMPILER_APPICON_NAME = AppIcon` integration proof while keeping the runtime asset count at 12.
- Converted rights language into required owner attestation and retained separate trademark clearance as an open release gate.

## Brand Handoff V4 — 2026-08-14

- Preserved all approved V2/V3 runtime imagery and introduced the six-card S10 plan, experience/store schemas, current Apple evidence topics, and a 92-point package score.

## V3 — 2026-08-14

- Added screen/state, accessibility, visual-regression, evidence-lock, research, and validator artifacts while preserving V2 imagery.

## V2 — 2026-08-14

- Corrected transparent Dark and grayscale Tinted sources, added production QA/contracts, and preserved the selected geometry and palette.

## V1 — 2026-08-14

- Established the identity, app-icon appearances, symbol assets, tokens, installation map, manifest, and source reference.

Earlier packages remain separate; V4.1 does not overwrite them.
